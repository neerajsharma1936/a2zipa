import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  UserRole,
  Internship,
  Application,
  Course,
  ContactDetails,
  Project,
  Certificate,
  NotificationItem,
  Conversation,
  ChatMessage,
  AuditLog,
  HeroBanner,
  StudentRegistration,
  StudentRegistrationStatus,
  UploadedDocFile,
  CourseInquiry,
} from '../types';
import {
  mockCurrentUser,
  mockUsersByRole,
  initialInternships,
  initialCourses,
  initialBranches,
  initialContactDetails,
  initialApplications,
  initialProjects,
  initialCertificates,
  initialNotifications,
  initialConversations,
  initialAuditLogs,
  initialHeroBanners,
  initialPlacements,
  initialQualifications,
  initialBranchesList,
  initialPassingYears,
  initialColleges,
  initialStudentRegistrations,
  initialCourseInquiries,
} from '../data/mockData';

export interface Toast {
  id: string;
  message: string;
  type?: 'success' | 'info' | 'warning' | 'error';
}

interface AppContextType {
  currentRole: UserRole;
  setRole: (role: UserRole) => void;
  currentUser: User;
  currentView: string;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  navigateTo: (
    view: string,
    params?: {
      internshipId?: string;
      courseId?: string;
      certId?: string;
      searchQuery?: string;
      selectedCourse?: string;
      tab?: string;
      category?: string;
    }
  ) => void;
  
  // Navigation targets
  currentInternshipId: string | null;
  setCurrentInternshipId: (id: string | null) => void;
  currentCourseId: string | null;
  setCurrentCourseId: (id: string | null) => void;
  currentCertId: string | null;
  setCurrentCertId: (id: string | null) => void;
  
  // Data
  internships: Internship[];
  savedInternshipIds: string[];
  toggleSaveInternship: (id: string) => void;
  addInternship: (internship: Omit<Internship, 'id' | 'postedDaysAgo' | 'postedDate'>) => void;
  
  courses: Course[];
  enrollInCourse: (courseId: string) => void;
  markLessonComplete: (courseId: string, moduleId: string, lessonId: string) => void;
  addCourse: (course: Omit<Course, 'id'> | Course) => string;
  updateCourse: (id: string, updated: Partial<Course>) => void;
  removeCourse: (id: string) => void;
  
  branches: string[];
  addBranch: (branchName: string) => void;
  removeBranch?: (branchName: string) => void;
  
  contactDetails: ContactDetails;
  updateContactDetails: (details: Partial<ContactDetails>) => void;
  
  applications: Application[];
  applyToInternship: (internshipId: string, coverLetter?: string, resumeName?: string) => boolean;
  updateApplicationStatus: (appId: string, newStatus: Application['status'], nextStep?: string, interviewDate?: string) => void;
  withdrawApplication: (appId: string) => void;
  
  projects: Project[];
  addProject: (project: Omit<Project, 'id' | 'studentId' | 'studentName'>) => void;
  updateProjectProgress: (projectId: string, progress: number, status?: Project['status']) => void;
  addMentorFeedback: (projectId: string, feedback: string, score: number) => void;
  
  certificates: Certificate[];
  generateCertificate: (courseTitle: string, studentName?: string) => Certificate;
  
  notifications: NotificationItem[];
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  
  conversations: Conversation[];
  activeConversationId: string;
  setActiveConversationId: (id: string) => void;
  messages: ChatMessage[];
  sendMessage: (conversationIdOrText: string, textOrAttachment?: any, attachment?: any) => void;
  cancelApplication?: (appId: string) => void;
  
  // Hero Banners (Admin Management & Public Carousel)
  heroBanners: HeroBanner[];
  addHeroBanner: (banner: Omit<HeroBanner, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateHeroBanner: (id: string, updated: Partial<HeroBanner>) => void;
  deleteHeroBanner: (id: string) => void;
  toggleHeroBannerStatus: (id: string) => void;
  reorderHeroBanners: (orderedIds: string[]) => void;
  
  auditLogs: AuditLog[];
  addAuditLog: (action: string, module: string, description: string) => void;
  
  // Student Registrations & Dynamic Form Options
  studentRegistrations: StudentRegistration[];
  addStudentRegistration: (data: Omit<StudentRegistration, 'id' | 'registrationNumber' | 'submittedAt' | 'status'>) => StudentRegistration;
  updateRegistrationStatus: (id: string, status: StudentRegistrationStatus, remarks?: string) => void;
  deleteRegistration: (id: string) => void;

  // Course Inquiries & Contact Applications
  courseInquiries: CourseInquiry[];
  addCourseInquiry: (inquiry: Omit<CourseInquiry, 'id' | 'inquiryNumber' | 'submittedAt' | 'status'>) => CourseInquiry;
  updateCourseInquiryStatus: (id: string, status: CourseInquiry['status']) => void;
  deleteCourseInquiry: (id: string) => void;
  selectedCourseForApplication: string;
  setSelectedCourseForApplication: (course: string) => void;
  
  placements: string[];
  addPlacement: (placement: string) => void;
  updatePlacement: (oldName: string, newName: string) => void;
  removePlacement: (placement: string) => void;
  
  qualifications: string[];
  addQualification: (qualification: string) => void;
  updateQualification: (oldName: string, newName: string) => void;
  removeQualification: (qualification: string) => void;
  
  branchesList: string[];
  addBranchOption: (branchName: string) => void;
  updateBranchOption: (oldName: string, newName: string) => void;
  removeBranchOption: (branchName: string) => void;
  
  passingYears: string[];
  addPassingYear: (year: string) => void;
  removePassingYear: (year: string) => void;

  colleges: string[];
  addCollege: (collegeName: string) => void;
  updateCollege: (oldName: string, newName: string) => void;
  removeCollege: (collegeName: string) => void;

  // Modals & Feedback
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  isLoginOpen: boolean;
  setIsLoginOpen: (open: boolean) => void;
  isApplyModalOpen: boolean;
  setIsApplyModalOpen: (open: boolean) => void;
  activeApplyInternship: Internship | null;
  openApplyModal: (internship: Internship) => void;
  
  toasts: Toast[];
  showToast: (message: string, type?: Toast['type']) => void;
  removeToast: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

function safeLoad<T>(key: string, fallback: T): T {
  try {
    const saved = localStorage.getItem(key);
    if (saved === null || saved === undefined) return fallback;
    const parsed = JSON.parse(saved);
    if (Array.isArray(fallback)) {
      return (Array.isArray(parsed) ? parsed : fallback) as T;
    }
    return parsed ?? fallback;
  } catch {
    return fallback;
  }
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Role & User
  const [currentRole, setCurrentRoleState] = useState<UserRole>('guest');
  const [currentUser, setCurrentUser] = useState<User>(mockUsersByRole.guest);
  
  // View Routing
  const [currentView, setCurrentView] = useState<string>('home');
  const [currentInternshipId, setCurrentInternshipId] = useState<string | null>('int_1');
  const [currentCourseId, setCurrentCourseId] = useState<string | null>('crs_1');
  const [currentCertId, setCurrentCertId] = useState<string | null>('SN-2024-9842X');
  
  // Entities
  const [internships, setInternships] = useState<Internship[]>(() =>
    safeLoad('skillnest_internships', initialInternships)
  );
  
  const [savedInternshipIds, setSavedInternshipIds] = useState<string[]>(() =>
    safeLoad('skillnest_saved_internships', ['int_1', 'int_3'])
  );
  
  const [courses, setCourses] = useState<Course[]>(() =>
    safeLoad('skillnest_courses', initialCourses)
  );

  const [branches, setBranches] = useState<string[]>(() =>
    safeLoad('skillnest_branches', initialBranches)
  );

  const [contactDetails, setContactDetails] = useState<ContactDetails>(() =>
    safeLoad('skillnest_contact_details', initialContactDetails)
  );
  
  const [applications, setApplications] = useState<Application[]>(() =>
    safeLoad('skillnest_applications', initialApplications)
  );
  
  const [projects, setProjects] = useState<Project[]>(() =>
    safeLoad('skillnest_projects', initialProjects)
  );
  
  const [certificates, setCertificates] = useState<Certificate[]>(() =>
    safeLoad('skillnest_certificates', initialCertificates)
  );
  
  const [notifications, setNotifications] = useState<NotificationItem[]>(() =>
    safeLoad('skillnest_notifications', initialNotifications)
  );
  
  const [conversations, setConversations] = useState<Conversation[]>(() =>
    safeLoad('skillnest_conversations', initialConversations)
  );
  const [activeConversationId, setActiveConversationId] = useState<string>('conv_1');
  
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() =>
    safeLoad('skillnest_audit_logs', initialAuditLogs)
  );

  // Hero Banners
  const [heroBanners, setHeroBanners] = useState<HeroBanner[]>(() =>
    safeLoad('skillnest_hero_banners', initialHeroBanners)
  );

  // Student Registrations & Dynamic Options
  const [studentRegistrations, setStudentRegistrations] = useState<StudentRegistration[]>(() =>
    safeLoad('skillnest_student_registrations', initialStudentRegistrations)
  );
  const [courseInquiries, setCourseInquiries] = useState<CourseInquiry[]>(() =>
    safeLoad('skillnest_course_inquiries', initialCourseInquiries)
  );
  const [selectedCourseForApplication, setSelectedCourseForApplication] = useState<string>('');
  const [placements, setPlacements] = useState<string[]>(() =>
    safeLoad('skillnest_placements', initialPlacements)
  );
  const [qualifications, setQualifications] = useState<string[]>(() =>
    safeLoad('skillnest_qualifications', initialQualifications)
  );
  const [branchesList, setBranchesList] = useState<string[]>(() =>
    safeLoad('skillnest_branches_list', initialBranchesList)
  );
  const [passingYears, setPassingYears] = useState<string[]>(() =>
    safeLoad('skillnest_passing_years', initialPassingYears)
  );
  const [colleges, setColleges] = useState<string[]>(() =>
    safeLoad('skillnest_colleges', initialColleges)
  );

  // Modals & Toasts
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [activeApplyInternship, setActiveApplyInternship] = useState<Internship | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem('skillnest_internships', JSON.stringify(internships));
  }, [internships]);

  useEffect(() => {
    localStorage.setItem('skillnest_saved_internships', JSON.stringify(savedInternshipIds));
  }, [savedInternshipIds]);

  useEffect(() => {
    localStorage.setItem('skillnest_courses', JSON.stringify(courses));
  }, [courses]);

  useEffect(() => {
    localStorage.setItem('skillnest_branches', JSON.stringify(branches));
  }, [branches]);

  useEffect(() => {
    localStorage.setItem('skillnest_contact_details', JSON.stringify(contactDetails));
  }, [contactDetails]);

  useEffect(() => {
    localStorage.setItem('skillnest_applications', JSON.stringify(applications));
  }, [applications]);

  useEffect(() => {
    localStorage.setItem('skillnest_projects', JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    localStorage.setItem('skillnest_certificates', JSON.stringify(certificates));
  }, [certificates]);

  useEffect(() => {
    localStorage.setItem('skillnest_notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem('skillnest_conversations', JSON.stringify(conversations));
  }, [conversations]);

  useEffect(() => {
    localStorage.setItem('skillnest_hero_banners', JSON.stringify(heroBanners));
  }, [heroBanners]);

  useEffect(() => {
    localStorage.setItem('skillnest_student_registrations', JSON.stringify(studentRegistrations));
  }, [studentRegistrations]);

  useEffect(() => {
    localStorage.setItem('skillnest_course_inquiries', JSON.stringify(courseInquiries));
  }, [courseInquiries]);

  useEffect(() => {
    localStorage.setItem('skillnest_placements', JSON.stringify(placements));
  }, [placements]);

  useEffect(() => {
    localStorage.setItem('skillnest_qualifications', JSON.stringify(qualifications));
  }, [qualifications]);

  useEffect(() => {
    localStorage.setItem('skillnest_branches_list', JSON.stringify(branchesList));
  }, [branchesList]);

  useEffect(() => {
    localStorage.setItem('skillnest_passing_years', JSON.stringify(passingYears));
  }, [passingYears]);

  useEffect(() => {
    localStorage.setItem('skillnest_colleges', JSON.stringify(colleges));
  }, [colleges]);

  const showToast = (message: string, type: Toast['type'] = 'info') => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 5);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const setRole = (role: UserRole) => {
    setCurrentRoleState(role);
    setCurrentUser(mockUsersByRole[role] || mockUsersByRole.guest);
    showToast(`Switched active role to: ${role.toUpperCase().replace('_', ' ')}`, 'info');
    
    // Auto-navigate to appropriate view if on a restricted dashboard
    if (role === 'student' && currentView.startsWith('admin')) {
      setCurrentView('home');
    } else if (role === 'mentor' && currentView.startsWith('admin')) {
      setCurrentView('all-programs');
    } else if (role === 'employer' && currentView.startsWith('admin')) {
      setCurrentView('all-programs');
    } else if ((role === 'admin' || role === 'super_admin') && !currentView.startsWith('admin')) {
      setCurrentView('admin-management');
    }
  };

  const navigateTo = (
    view: string,
    params?: {
      internshipId?: string;
      courseId?: string;
      certId?: string;
      searchQuery?: string;
      selectedCourse?: string;
      tab?: string;
      category?: string;
    }
  ) => {
    if (params?.internshipId) setCurrentInternshipId(params.internshipId);
    if (params?.courseId) setCurrentCourseId(params.courseId);
    if (params?.certId) setCurrentCertId(params.certId);
    if (params?.searchQuery !== undefined) setSearchQuery(params.searchQuery);
    if (params?.selectedCourse !== undefined) {
      setSelectedCourseForApplication(params.selectedCourse);
    }
    
    // Normalization for application views
    if (view === 'apply' || view === 'application' || view === 'contact') {
      setCurrentView('student-registration');
    } else {
      setCurrentView(view);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const toggleSaveInternship = (id: string) => {
    setSavedInternshipIds((prev) => {
      const exists = prev.includes(id);
      const updated = exists ? prev.filter((item) => item !== id) : [...prev, id];
      showToast(exists ? 'Internship removed from saved items' : 'Internship saved to your list', 'success');
      return updated;
    });
  };

  const addInternship = (newInternshipData: Omit<Internship, 'id' | 'postedDaysAgo' | 'postedDate'>) => {
    const newId = `int_${Date.now()}`;
    const newInternship: Internship = {
      ...newInternshipData,
      id: newId,
      postedDaysAgo: 0,
      postedDate: 'Today',
    };
    setInternships((prev) => [newInternship, ...prev]);
    addAuditLog('Created Internship', 'Internships', `Published "${newInternship.title}" for ${newInternship.company}`);
    showToast(`"${newInternship.title}" has been published live!`, 'success');
  };

  const enrollInCourse = (courseId: string) => {
    setCourses((prev) =>
      prev.map((c) => (c.id === courseId ? { ...c, isEnrolled: true, progress: c.progress || 5 } : c))
    );
    showToast('Enrolled in course successfully! Access granted.', 'success');
    setCurrentCourseId(courseId);
  };

  const markLessonComplete = (courseId: string, moduleId: string, lessonId: string) => {
    setCourses((prev) =>
      prev.map((course) => {
        if (course.id !== courseId) return course;
        
        let totalLessons = 0;
        let completedLessons = 0;
        
        const updatedModules = course.modules.map((mod) => {
          const updatedLessons = mod.lessons.map((les) => {
            totalLessons++;
            if (les.id === lessonId || les.isCompleted) {
              completedLessons++;
              return { ...les, isCompleted: true };
            }
            return les;
          });
          return { ...mod, lessons: updatedLessons };
        });

        const newProgress = totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 100;
        return {
          ...course,
          modules: updatedModules,
          progress: Math.min(100, Math.max(course.progress || 0, newProgress)),
        };
      })
    );
    showToast('Lesson completed! Progress updated.', 'success');
  };

  const addCourse = (courseData: Omit<Course, 'id'> | Course): string => {
    const newId = 'id' in courseData && courseData.id ? courseData.id : `crs_${Date.now()}`;
    const newCourse: Course = {
      id: newId,
      rating: 4.8,
      reviewCount: 0,
      studentsCount: 0,
      modules: [],
      progress: 0,
      isEnrolled: false,
      status: 'Active',
      branch: 'B.Tech',
      ...courseData,
    };
    setCourses((prev) => [newCourse, ...prev]);
    addAuditLog('ADD_COURSE', 'Course Management', `Added course "${newCourse.title}" (${newCourse.branch || 'General'})`);
    showToast(`Course "${newCourse.title}" created successfully!`, 'success');
    return newId;
  };

  const updateCourse = (id: string, updated: Partial<Course>) => {
    setCourses((prev) =>
      prev.map((c) => {
        if (c.id === id) {
          const newCourse = { ...c, ...updated };
          return newCourse;
        }
        return c;
      })
    );
    addAuditLog('UPDATE_COURSE', 'Course Management', `Updated course details for ID: ${id}`);
    showToast('Course details saved and updated successfully!', 'success');
  };

  const removeCourse = (id: string) => {
    const target = courses.find((c) => c.id === id);
    const title = target?.title || id;
    setCourses((prev) => prev.filter((c) => c.id !== id));
    addAuditLog('DELETE_COURSE', 'Course Management', `Deleted course "${title}"`);
    showToast(`Course "${title}" removed successfully.`, 'info');
  };

  const addBranch = (branchName: string) => {
    const trimmed = branchName.trim();
    if (!trimmed) return;
    if (branches.includes(trimmed)) {
      showToast(`Branch "${trimmed}" already exists.`, 'info');
      return;
    }
    setBranches((prev) => [...prev, trimmed]);
    addAuditLog('ADD_BRANCH', 'Branch Management', `Created new educational branch: ${trimmed}`);
    showToast(`Branch "${trimmed}" added successfully!`, 'success');
  };

  const removeBranch = (branchName: string) => {
    setBranches((prev) => prev.filter((b) => b !== branchName));
    addAuditLog('DELETE_BRANCH', 'Branch Management', `Removed branch: ${branchName}`);
    showToast(`Branch "${branchName}" removed.`, 'info');
  };

  const updateContactDetails = (details: Partial<ContactDetails>) => {
    setContactDetails((prev) => ({
      ...prev,
      ...details,
    }));
    addAuditLog('UPDATE_CONTACT', 'Contact Details', 'Updated public contact and admission helpline');
    showToast('Contact and helpline details updated successfully!', 'success');
  };

  const applyToInternship = (internshipId: string, coverLetter?: string, resumeName: string = 'Rahul_Sharma_Resume.pdf'): boolean => {
    const internship = internships.find((i) => i.id === internshipId);
    if (!internship) return false;

    // Prevent duplicate application
    const existing = applications.find(
      (a) => a.internshipId === internshipId && a.studentId === currentUser.id
    );
    if (existing) {
      showToast('You have already applied for this internship.', 'warning');
      return false;
    }

    const newApp: Application = {
      id: `app_${Date.now()}`,
      internshipId: internship.id,
      internshipTitle: internship.title,
      company: internship.company,
      companyLogo: internship.companyLogo,
      studentId: currentUser.id,
      studentName: currentUser.name,
      studentEmail: currentUser.email,
      studentAvatar: currentUser.avatar,
      appliedDate: 'Just now',
      status: 'Applied',
      nextStep: 'Application submitted. Pending review by hiring team.',
      resumeUrl: resumeName,
      coverLetter: coverLetter || 'I am eager to contribute with my skills in software development.',
      stipendText: internship.stipendText,
      location: internship.location,
    };

    setApplications((prev) => [newApp, ...prev]);
    
    // Add student notification
    const newNotif: NotificationItem = {
      id: `notif_${Date.now()}`,
      title: 'Application Submitted',
      description: `Your application for ${internship.title} at ${internship.company} was received.`,
      time: 'Just now',
      category: 'Applications',
      isRead: false,
      actionUrl: 'all-programs',
    };
    setNotifications((prev) => [newNotif, ...prev]);

    showToast('Application submitted successfully!', 'success');
    return true;
  };

  const updateApplicationStatus = (
    appId: string,
    newStatus: Application['status'],
    nextStep?: string,
    interviewDate?: string
  ) => {
    setApplications((prev) =>
      prev.map((app) => {
        if (app.id !== appId) return app;
        return {
          ...app,
          status: newStatus,
          nextStep: nextStep || app.nextStep,
          interviewDate: interviewDate || app.interviewDate,
        };
      })
    );
    
    // Create notification
    const targetApp = applications.find((a) => a.id === appId);
    if (targetApp) {
      const newNotif: NotificationItem = {
        id: `notif_${Date.now()}`,
        title: `Application Status: ${newStatus}`,
        description: `${targetApp.company} updated your application for ${targetApp.internshipTitle} to ${newStatus}.`,
        time: 'Just now',
        category: 'Applications',
        isRead: false,
        actionUrl: 'all-programs',
      };
      setNotifications((prev) => [newNotif, ...prev]);
    }

    addAuditLog('Updated Application Status', 'Applications', `Status changed to ${newStatus} for Application #${appId}`);
    showToast(`Application updated to ${newStatus}`, 'success');
  };

  const withdrawApplication = (appId: string) => {
    setApplications((prev) => prev.filter((a) => a.id !== appId));
    showToast('Application withdrawn successfully', 'info');
  };

  const addProject = (projectData: Omit<Project, 'id' | 'studentId' | 'studentName'>) => {
    const newProject: Project = {
      ...projectData,
      id: `prj_${Date.now()}`,
      studentId: currentUser.id,
      studentName: currentUser.name,
    };
    setProjects((prev) => [newProject, ...prev]);
    showToast(`Project "${newProject.title}" added to your portfolio!`, 'success');
  };

  const updateProjectProgress = (projectId: string, progress: number, status?: Project['status']) => {
    setProjects((prev) =>
      prev.map((p) => {
        if (p.id !== projectId) return p;
        const newStatus = status || (progress >= 100 ? 'Completed' : progress > 0 ? 'In Progress' : 'Not Started');
        return { ...p, progress, status: newStatus };
      })
    );
    showToast('Project progress updated!', 'success');
  };

  const addMentorFeedback = (projectId: string, feedback: string, score: number) => {
    setProjects((prev) =>
      prev.map((p) => {
        if (p.id !== projectId) return p;
        return {
          ...p,
          mentorFeedback: feedback,
          mentorScore: score,
          status: 'In Progress',
        };
      })
    );
    
    const newNotif: NotificationItem = {
      id: `notif_${Date.now()}`,
      title: 'Mentor Feedback Received',
      description: `Your mentor scored your project (${score}/100) with personalized feedback.`,
      time: 'Just now',
      category: 'Projects',
      isRead: false,
      actionUrl: 'notifications',
    };
    setNotifications((prev) => [newNotif, ...prev]);
    showToast('Feedback submitted to student successfully', 'success');
  };

  const generateCertificate = (courseTitle: string, studentName?: string): Certificate => {
    const certNum = Math.floor(1000 + Math.random() * 9000);
    const certLetter = String.fromCharCode(65 + Math.floor(Math.random() * 26));
    const newId = `SN-${new Date().getFullYear()}-${certNum}${certLetter}`;
    
    const newCert: Certificate = {
      id: `cert_${Date.now()}`,
      certificateId: newId,
      studentName: studentName || currentUser.name,
      courseTitle,
      issueDate: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
      directorName: 'Siddharth Sengupta',
      directorTitle: 'Academic Director, SkillNest Institute',
      qrCodeUrl: `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://skillnest.org/verify-certificate/${newId}`,
      skillsAcquired: ['Full Stack Development', 'React Architecture', 'System Design', 'Production Deployment'],
      grade: 'A+ (Distinction)',
      verificationUrl: `/verify-certificate/${newId}`,
    };

    setCertificates((prev) => [newCert, ...prev]);
    
    const newNotif: NotificationItem = {
      id: `notif_${Date.now()}`,
      title: 'Certificate Issued!',
      description: `Official Certificate for ${courseTitle} is ready to view & download.`,
      time: 'Just now',
      category: 'System',
      isRead: false,
      actionUrl: 'student-certificates',
    };
    setNotifications((prev) => [newNotif, ...prev]);

    showToast(`Certificate ${newId} generated successfully!`, 'success');
    return newCert;
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)));
  };

  const markAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    showToast('All notifications marked as read', 'info');
  };

  const sendMessage = (conversationIdOrText: string, textOrAttachment?: any, attachment?: any) => {
    let targetConvId = activeConversationId;
    let messageText = '';
    let messageAttach: { name: string; size: string; type: string } | undefined = undefined;

    if (typeof textOrAttachment === 'string') {
      targetConvId = conversationIdOrText;
      messageText = textOrAttachment;
      messageAttach = attachment;
    } else {
      messageText = conversationIdOrText;
      messageAttach = textOrAttachment;
    }

    if (!messageText.trim() && !messageAttach) return;

    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      senderRole: currentRole,
      text: messageText.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      attachment: messageAttach,
      isMine: true,
      isMe: true,
    };

    setConversations((prev) =>
      prev.map((conv) => {
        if (conv.id !== targetConvId) return conv;
        return {
          ...conv,
          lastMessage: messageText.trim() || `Sent an attachment: ${messageAttach?.name}`,
          lastMessageTime: 'Just now',
          messages: [...(conv.messages || []), newMsg],
        };
      })
    );
  };

  const activeConversation = conversations.find((c) => c.id === activeConversationId) || conversations[0];
  const messages: ChatMessage[] = activeConversation?.messages || [];

  const addAuditLog = (action: string, module: string, description: string) => {
    const newLog: AuditLog = {
      id: `log_${Date.now()}`,
      adminName: currentUser.name,
      adminEmail: currentUser.email,
      action,
      module,
      description,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      ipAddress: '103.21.144.18',
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  const openApplyModal = (internship: Internship) => {
    setActiveApplyInternship(internship);
    setIsApplyModalOpen(true);
  };

  const addHeroBanner = (bannerData: Omit<HeroBanner, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newId = `banner_${Date.now()}`;
    const now = new Date().toISOString();
    const newBanner: HeroBanner = {
      ...bannerData,
      id: newId,
      createdAt: now,
      updatedAt: now,
    };
    setHeroBanners((prev) => [...prev, newBanner].sort((a, b) => a.order - b.order));
    addAuditLog('Banner Created', 'Hero Banner Management', `Added banner "${newBanner.title}"`);
    showToast(`Banner "${newBanner.title}" added successfully`, 'success');
  };

  const updateHeroBanner = (id: string, updated: Partial<HeroBanner>) => {
    const now = new Date().toISOString();
    setHeroBanners((prev) =>
      prev.map((b) => (b.id === id ? { ...b, ...updated, updatedAt: now } : b)).sort((a, b) => a.order - b.order)
    );
    const existing = heroBanners.find((b) => b.id === id);
    addAuditLog('Banner Updated', 'Hero Banner Management', `Updated banner "${existing?.title || id}"`);
    showToast('Banner updated successfully', 'success');
  };

  const deleteHeroBanner = (id: string) => {
    const target = heroBanners.find((b) => b.id === id);
    setHeroBanners((prev) => prev.filter((b) => b.id !== id));
    addAuditLog('Banner Deleted', 'Hero Banner Management', `Deleted banner "${target?.title || id}"`);
    showToast('Banner permanently deleted', 'info');
  };

  const toggleHeroBannerStatus = (id: string) => {
    setHeroBanners((prev) =>
      prev.map((b) => {
        if (b.id === id) {
          const newStatus = !b.active;
          showToast(`Banner "${b.title}" is now ${newStatus ? 'Active' : 'Inactive'}`, 'info');
          return { ...b, active: newStatus, updatedAt: new Date().toISOString() };
        }
        return b;
      })
    );
  };

  const reorderHeroBanners = (orderedIds: string[]) => {
    setHeroBanners((prev) => {
      const bannerMap = new Map<string, HeroBanner>();
      prev.forEach((b) => bannerMap.set(b.id, b));
      const result: HeroBanner[] = [];
      orderedIds.forEach((id, index) => {
        const item = bannerMap.get(id);
        if (item) {
          result.push({ ...item, order: index + 1 });
        }
      });
      prev.forEach((b) => {
        if (!orderedIds.includes(b.id)) {
          result.push({ ...b, order: result.length + 1 });
        }
      });
      return result;
    });
    showToast('Banner order updated', 'success');
  };

  // Student Registration Handlers
  const addStudentRegistration = (
    data: Omit<StudentRegistration, 'id' | 'registrationNumber' | 'submittedAt' | 'status'>
  ): StudentRegistration => {
    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const regNumber = `REG-${new Date().getFullYear()}-${randomSuffix}`;
    const newReg: StudentRegistration = {
      ...data,
      id: `reg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      registrationNumber: regNumber,
      status: 'Pending',
      submittedAt: new Date().toISOString(),
    };
    setStudentRegistrations((prev) => [newReg, ...prev]);
    addAuditLog('Student Registration Submitted', 'Student Registrations', `New registration ${regNumber} by ${data.name}`);
    return newReg;
  };

  const updateRegistrationStatus = (id: string, status: StudentRegistrationStatus, remarks?: string) => {
    setStudentRegistrations((prev) =>
      prev.map((reg) =>
        reg.id === id
          ? {
              ...reg,
              status,
              adminRemarks: remarks !== undefined ? remarks : reg.adminRemarks,
            }
          : reg
      )
    );
    const target = studentRegistrations.find((r) => r.id === id);
    addAuditLog('Registration Status Updated', 'Student Registrations', `Updated ${target?.registrationNumber || id} to ${status}`);
    showToast(`Registration status updated to ${status}`, 'success');
  };

  const deleteRegistration = (id: string) => {
    const target = studentRegistrations.find((r) => r.id === id);
    setStudentRegistrations((prev) => prev.filter((r) => r.id !== id));
    addAuditLog('Registration Deleted', 'Student Registrations', `Deleted registration ${target?.registrationNumber || id}`);
    showToast('Registration deleted', 'info');
  };

  // Course Inquiry Handlers
  const addCourseInquiry = (
    inquiryData: Omit<CourseInquiry, 'id' | 'inquiryNumber' | 'submittedAt' | 'status'>
  ): CourseInquiry => {
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const inqNumber = `INQ-${new Date().getFullYear()}-${randomSuffix}`;
    const newInquiry: CourseInquiry = {
      ...inquiryData,
      id: `inq_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      inquiryNumber: inqNumber,
      submittedAt: new Date().toISOString(),
      status: 'New',
    };
    setCourseInquiries((prev) => [newInquiry, ...prev]);
    addAuditLog(
      'Course Application / Inquiry Submitted',
      'Contact & Applications',
      `New inquiry ${inqNumber} for "${newInquiry.selectedCourse}" by ${newInquiry.name}`
    );
    return newInquiry;
  };

  const updateCourseInquiryStatus = (id: string, status: CourseInquiry['status']) => {
    setCourseInquiries((prev) =>
      prev.map((inq) => (inq.id === id ? { ...inq, status } : inq))
    );
    const target = courseInquiries.find((i) => i.id === id);
    addAuditLog(
      'Inquiry Status Updated',
      'Contact & Applications',
      `Updated ${target?.inquiryNumber || id} to ${status}`
    );
    showToast(`Inquiry status updated to ${status}`, 'success');
  };

  const deleteCourseInquiry = (id: string) => {
    const target = courseInquiries.find((i) => i.id === id);
    setCourseInquiries((prev) => prev.filter((i) => i.id !== id));
    addAuditLog(
      'Inquiry Deleted',
      'Contact & Applications',
      `Deleted inquiry ${target?.inquiryNumber || id}`
    );
    showToast('Inquiry deleted', 'info');
  };

  // Placement Options Handlers
  const addPlacement = (placementName: string) => {
    const trimmed = placementName.trim();
    if (!trimmed) return;
    if (placements.includes(trimmed)) {
      showToast('Placement option already exists', 'warning');
      return;
    }
    setPlacements((prev) => [...prev, trimmed]);
    addAuditLog('Placement Option Added', 'Admin Options', `Added placement "${trimmed}"`);
    showToast('Placement option added', 'success');
  };

  const updatePlacement = (oldName: string, newName: string) => {
    const trimmed = newName.trim();
    if (!trimmed || oldName === trimmed) return;
    setPlacements((prev) => prev.map((p) => (p === oldName ? trimmed : p)));
    addAuditLog('Placement Option Renamed', 'Admin Options', `Renamed placement "${oldName}" to "${trimmed}"`);
    showToast('Placement option updated', 'success');
  };

  const removePlacement = (placementName: string) => {
    setPlacements((prev) => prev.filter((p) => p !== placementName));
    addAuditLog('Placement Option Removed', 'Admin Options', `Removed placement "${placementName}"`);
    showToast('Placement option removed', 'info');
  };

  // Qualification Options Handlers
  const addQualification = (qualName: string) => {
    const trimmed = qualName.trim();
    if (!trimmed) return;
    if (qualifications.includes(trimmed)) {
      showToast('Qualification already exists', 'warning');
      return;
    }
    setQualifications((prev) => [...prev, trimmed]);
    addAuditLog('Qualification Option Added', 'Admin Options', `Added qualification "${trimmed}"`);
    showToast('Qualification option added', 'success');
  };

  const updateQualification = (oldName: string, newName: string) => {
    const trimmed = newName.trim();
    if (!trimmed || oldName === trimmed) return;
    setQualifications((prev) => prev.map((q) => (q === oldName ? trimmed : q)));
    addAuditLog('Qualification Option Renamed', 'Admin Options', `Renamed qualification "${oldName}" to "${trimmed}"`);
    showToast('Qualification option updated', 'success');
  };

  const removeQualification = (qualName: string) => {
    setQualifications((prev) => prev.filter((q) => q !== qualName));
    addAuditLog('Qualification Option Removed', 'Admin Options', `Removed qualification "${qualName}"`);
    showToast('Qualification option removed', 'info');
  };

  // Branches Options Handlers
  const addBranchOption = (branchName: string) => {
    const trimmed = branchName.trim();
    if (!trimmed) return;
    if (branchesList.includes(trimmed)) {
      showToast('Branch already exists', 'warning');
      return;
    }
    setBranchesList((prev) => [...prev, trimmed]);
    addAuditLog('Branch Option Added', 'Admin Options', `Added branch "${trimmed}"`);
    showToast('Branch option added', 'success');
  };

  const updateBranchOption = (oldName: string, newName: string) => {
    const trimmed = newName.trim();
    if (!trimmed || oldName === trimmed) return;
    setBranchesList((prev) => prev.map((b) => (b === oldName ? trimmed : b)));
    addAuditLog('Branch Option Renamed', 'Admin Options', `Renamed branch "${oldName}" to "${trimmed}"`);
    showToast('Branch option updated', 'success');
  };

  const removeBranchOption = (branchName: string) => {
    setBranchesList((prev) => prev.filter((b) => b !== branchName));
    addAuditLog('Branch Option Removed', 'Admin Options', `Removed branch "${branchName}"`);
    showToast('Branch option removed', 'info');
  };

  // Passing Years Handlers
  const addPassingYear = (year: string) => {
    const trimmed = year.trim();
    if (!trimmed) return;
    if (passingYears.includes(trimmed)) {
      showToast('Year already exists', 'warning');
      return;
    }
    setPassingYears((prev) => [trimmed, ...prev]);
    addAuditLog('Passing Year Added', 'Admin Options', `Added passing year "${trimmed}"`);
    showToast('Passing year added', 'success');
  };

  const removePassingYear = (year: string) => {
    setPassingYears((prev) => prev.filter((y) => y !== year));
    addAuditLog('Passing Year Removed', 'Admin Options', `Removed passing year "${year}"`);
    showToast('Passing year removed', 'info');
  };

  // College / Institute Options Handlers
  const addCollege = (collegeName: string) => {
    const trimmed = collegeName.trim();
    if (!trimmed) return;
    if (colleges.includes(trimmed)) {
      showToast('College already exists in list', 'warning');
      return;
    }
    setColleges((prev) => [...prev, trimmed]);
    addAuditLog('College Option Added', 'Admin Options', `Added college "${trimmed}"`);
    showToast('College added to list', 'success');
  };

  const updateCollege = (oldName: string, newName: string) => {
    const trimmed = newName.trim();
    if (!trimmed || oldName === trimmed) return;
    setColleges((prev) => prev.map((c) => (c === oldName ? trimmed : c)));
    addAuditLog('College Option Renamed', 'Admin Options', `Renamed college "${oldName}" to "${trimmed}"`);
    showToast('College updated', 'success');
  };

  const removeCollege = (collegeName: string) => {
    setColleges((prev) => prev.filter((c) => c !== collegeName));
    addAuditLog('College Option Removed', 'Admin Options', `Removed college "${collegeName}"`);
    showToast('College removed from list', 'info');
  };

  return (
    <AppContext.Provider
      value={{
        currentRole,
        setRole,
        currentUser,
        currentView,
        navigateTo,
        currentInternshipId,
        setCurrentInternshipId,
        currentCourseId,
        setCurrentCourseId,
        currentCertId,
        setCurrentCertId,
        internships,
        savedInternshipIds,
        toggleSaveInternship,
        addInternship,
        courses,
        enrollInCourse,
        markLessonComplete,
        addCourse,
        updateCourse,
        removeCourse,
        branches,
        addBranch,
        removeBranch,
        contactDetails,
        updateContactDetails,
        applications,
        applyToInternship,
        updateApplicationStatus,
        withdrawApplication,
        cancelApplication: withdrawApplication,
        projects,
        addProject,
        updateProjectProgress,
        addMentorFeedback,
        certificates,
        generateCertificate,
        notifications,
        markNotificationRead,
        markAllNotificationsRead,
        conversations,
        activeConversationId,
        setActiveConversationId,
        messages,
        sendMessage,
        heroBanners,
        addHeroBanner,
        updateHeroBanner,
        deleteHeroBanner,
        toggleHeroBannerStatus,
        reorderHeroBanners,
        studentRegistrations,
        addStudentRegistration,
        updateRegistrationStatus,
        deleteRegistration,
        courseInquiries,
        addCourseInquiry,
        updateCourseInquiryStatus,
        deleteCourseInquiry,
        selectedCourseForApplication,
        setSelectedCourseForApplication,
        placements,
        addPlacement,
        updatePlacement,
        removePlacement,
        qualifications,
        addQualification,
        updateQualification,
        removeQualification,
        branchesList,
        addBranchOption,
        updateBranchOption,
        removeBranchOption,
        passingYears,
        addPassingYear,
        removePassingYear,
        colleges,
        addCollege,
        updateCollege,
        removeCollege,
        auditLogs,
        addAuditLog,
        searchQuery,
        setSearchQuery,
        isSearchOpen,
        setIsSearchOpen,
        isLoginOpen,
        setIsLoginOpen,
        isApplyModalOpen,
        setIsApplyModalOpen,
        activeApplyInternship,
        openApplyModal,
        toasts,
        showToast,
        removeToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
