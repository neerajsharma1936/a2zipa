import React, { useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { RoleSwitcherBar } from './components/layout/RoleSwitcherBar';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { ToastContainer } from './components/ui/ToastContainer';
import { GlobalSearchModal } from './components/modals/GlobalSearchModal';
import { LoginModal } from './components/modals/LoginModal';
import { ApplyInternshipModal } from './components/modals/ApplyInternshipModal';

// Views
import { HomeView } from './views/HomeView';
import { CertificatesView } from './views/CertificatesView';
import { NotificationsView } from './views/NotificationsView';
import { MessagesView } from './views/MessagesView';
import { AllProgramsView } from './views/AllProgramsView';
import { AdminManagementView } from './views/AdminManagementView';
import { StudentRegistrationView } from './views/StudentRegistrationView';
import { ApplicationContactView } from './views/ApplicationContactView';

const AppContent: React.FC = () => {
  const { currentView } = useApp();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentView]);

  const renderCurrentView = () => {
    switch (currentView) {
      case 'home':
        return <HomeView />;
      case 'application':
      case 'apply':
      case 'contact':
      case 'contact-us':
      case 'student-application':
        return <ApplicationContactView />;
      case 'student-registration':
      case 'registration':
      case 'get-started':
        return <StudentRegistrationView />;
      case 'all-programs':
      case 'programs':
        return <AllProgramsView />;
      case 'student-certificates':
      case 'verify-certificate':
        return <CertificatesView />;
      case 'notifications':
        return <NotificationsView />;
      case 'messages':
        return <MessagesView />;
      case 'admin-management':
      case 'admin-dashboard':
      case 'admin':
        return <AdminManagementView />;
      default:
        return <HomeView />;
    }
  };

  const isLMSFullscreen = false;
  const isDashboardView = [
    'admin-management',
    'admin-dashboard',
    'admin',
    'student-certificates',
    'verify-certificate',
    'messages',
    'notifications',
  ].includes(currentView);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 selection:bg-blue-500 selection:text-white">
      {/* Interactive multi-role demo bar */}
      <RoleSwitcherBar />

      {/* Primary Navigation Header */}
      {!isLMSFullscreen && <Header />}

      {/* Main View Area */}
      <div className="flex-1 flex flex-col">
        {renderCurrentView()}
      </div>

      {/* Footer for public pages */}
      {!isDashboardView && <Footer />}

      {/* Global Modals & Notifications */}
      <GlobalSearchModal />
      <LoginModal />
      <ApplyInternshipModal />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
