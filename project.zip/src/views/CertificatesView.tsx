import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DashboardSidebar } from '../components/layout/DashboardSidebar';
import {
  Award,
  Download,
  Share2,
  CheckCircle2,
  QrCode,
  Search,
  ExternalLink,
  Printer,
  ShieldCheck,
  X,
  Sparkles
} from 'lucide-react';

export const CertificatesView: React.FC = () => {
  const { certificates, showToast } = useApp();

  const [verifyQuery, setVerifyQuery] = useState('');
  const [activeCertificate, setActiveCertificate] = useState<any>(certificates[0] || null);
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [verificationResult, setVerificationResult] = useState<any>(null);

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifyQuery.trim()) return;

    const match = certificates.find(
      (c) => c.certificateId.toLowerCase() === verifyQuery.trim().toLowerCase()
    );

    if (match) {
      setVerificationResult({
        valid: true,
        data: match,
      });
      showToast(`Valid Certificate ID: ${match.certificateId}`, 'success');
    } else {
      setVerificationResult({
        valid: false,
        message: 'No record found with ID ' + verifyQuery,
      });
      showToast('Certificate not found in central registry', 'error');
    }
  };

  const handleDownload = (cert: any) => {
    showToast(`Generating official PDF for ${cert.title}...`, 'info');
    setTimeout(() => {
      showToast(`Downloaded: ${cert.certificateId}.pdf`, 'success');
    }, 800);
  };

  const handleShareLinkedIn = (cert: any) => {
    const text = `Excited to have earned my verified certificate in ${cert.title} from SkillNest! Certificate ID: ${cert.certificateId}`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      showToast('LinkedIn share announcement copied to clipboard!', 'success');
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F8FF] flex">
      <DashboardSidebar activeTab="certificates" />

      <main className="flex-1 p-4 sm:p-6 lg:p-8 space-y-6 overflow-y-auto bg-[#F4F8FF]">
        
        {/* Top Header matching Screen 10 */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
              Certificates & Credentials ({certificates.length})
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              Cryptographically verified credentials recognizable by top hiring partners
            </p>
          </div>

          {/* Quick Verify input */}
          <form onSubmit={handleVerify} className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Verify ID (e.g. SKILL-2024-8841)..."
                value={verifyQuery}
                onChange={(e) => setVerifyQuery(e.target.value)}
                className="text-xs pl-8 pr-3 py-2 bg-white rounded-xl border border-slate-200 focus:outline-none focus:border-blue-600 text-slate-800 w-48 sm:w-60"
              />
            </div>
            <button
              type="submit"
              className="px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl transition-colors cursor-pointer"
            >
              Verify
            </button>
          </form>
        </div>

        {/* Verification Result Notification */}
        {verificationResult && (
          <div className={`p-4 rounded-2xl border text-xs flex items-start justify-between gap-4 ${
            verificationResult.valid ? 'bg-emerald-50 border-emerald-200 text-emerald-900' : 'bg-rose-50 border-rose-200 text-rose-900'
          }`}>
            <div className="flex items-center gap-3">
              <ShieldCheck className={`w-6 h-6 ${verificationResult.valid ? 'text-emerald-600' : 'text-rose-600'}`} />
              <div>
                <p className="font-bold text-sm">
                  {verificationResult.valid ? '✓ Official Authentic Certificate Confirmed' : '✗ Verification Failed'}
                </p>
                <p className="text-xs mt-0.5">
                  {verificationResult.valid
                    ? `Recipient: ${verificationResult.data.recipientName} • Course: ${verificationResult.data.title} • Issued: ${verificationResult.data.issueDate}`
                    : verificationResult.message}
                </p>
              </div>
            </div>
            <button onClick={() => setVerificationResult(null)} className="text-slate-400 hover:text-slate-600">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Certificate Cards Grid matching Screen 10 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {certificates.map((cert) => (
            <div
              key={cert.id}
              className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
            >
              {/* Card visual mockup */}
              <div
                onClick={() => {
                  setActiveCertificate(cert);
                  setIsViewerOpen(true);
                }}
                className="bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 p-6 text-white text-center relative cursor-pointer group"
              >
                <div className="border border-amber-400/40 p-4 rounded-xl space-y-2 relative">
                  <span className="text-[9px] uppercase tracking-widest text-amber-300 font-bold block">
                    Certificate of Excellence
                  </span>
                  <h3 className="text-sm font-black text-white group-hover:text-amber-200 transition-colors line-clamp-1">
                    {cert.title || cert.courseTitle}
                  </h3>
                  <p className="text-[11px] text-slate-300 font-serif italic">{cert.recipientName || cert.studentName}</p>
                  
                  <div className="pt-2 flex items-center justify-between text-[9px] text-slate-400 border-t border-slate-700/60">
                    <span>ID: {cert.certificateId}</span>
                    <span className="text-emerald-400 font-bold">Grade: {cert.grade}</span>
                  </div>
                </div>

                <span className="absolute bottom-2 right-2 text-[10px] text-blue-300 opacity-0 group-hover:opacity-100 transition-opacity">
                  Click to inspect full view ↗
                </span>
              </div>

              {/* Info & Metadata */}
              <div className="p-5 space-y-3">
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Issue Date</span>
                    <span className="font-semibold text-slate-700">{cert.issueDate}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Issuer</span>
                    <span className="font-semibold text-slate-700">{cert.issuer || cert.directorName || 'SkillNest Academic Council'}</span>
                  </div>
                </div>

                {/* Skills gained */}
                <div className="flex flex-wrap gap-1 pt-1">
                  {(cert.skillsAcquired || cert.skills || []).map((s: string) => (
                    <span key={s} className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded">
                      {s}
                    </span>
                  ))}
                </div>

                {/* Action buttons matching Screen 10 */}
                <div className="pt-3 border-t border-slate-100 grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleDownload(cert)}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download PDF</span>
                  </button>

                  <button
                    onClick={() => handleShareLinkedIn(cert)}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>Share</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* FULL DIPLOMA VIEWER MODAL (Screen 10 Match) */}
        {isViewerOpen && activeCertificate && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
            <div className="bg-white rounded-3xl max-w-2xl w-full p-8 shadow-2xl relative space-y-6">
              
              <button
                onClick={() => setIsViewerOpen(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Classical Certificate Layout */}
              <div className="border-8 border-double border-amber-600/30 p-8 rounded-2xl bg-amber-50/20 text-center space-y-4 relative overflow-hidden">
                
                {/* Crest */}
                <div className="w-16 h-16 rounded-full bg-amber-100 border-2 border-amber-400 flex items-center justify-center mx-auto text-amber-700 shadow-sm">
                  <Award className="w-8 h-8" />
                </div>

                <div className="space-y-1">
                  <span className="text-[11px] font-bold text-amber-800 uppercase tracking-widest">
                    SkillNest Professional Certification
                  </span>
                  <h2 className="text-2xl font-serif font-black text-slate-900">
                    Certificate of Excellence
                  </h2>
                  <p className="text-xs text-slate-500">This credential is proudly presented to</p>
                </div>

                <p className="text-3xl font-serif text-blue-900 font-bold border-b border-amber-300 pb-2 max-w-sm mx-auto">
                  {activeCertificate.recipientName || activeCertificate.studentName}
                </p>

                <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
                  For successfully fulfilling all rigorous program requirements, completing real-world capstones,
                  and demonstrating mastery in <strong>{activeCertificate.title || activeCertificate.courseTitle}</strong> with an aggregate score of{' '}
                  <strong>{activeCertificate.grade}</strong>.
                </p>

                {/* Signatures & QR Code */}
                <div className="pt-6 border-t border-amber-200/80 flex items-center justify-between text-xs">
                  <div className="text-left">
                    <p className="font-serif italic text-base text-slate-800">Dr. Priya Patel</p>
                    <p className="text-[10px] text-slate-400 uppercase tracking-wider">Academic Director</p>
                  </div>

                  {/* QR Code */}
                  <div className="text-center p-2 bg-white rounded-xl border border-slate-200 shadow-xs">
                    <QrCode className="w-12 h-12 text-slate-900 mx-auto" />
                    <span className="text-[9px] text-slate-500 font-mono block mt-1">
                      {activeCertificate.certificateId}
                    </span>
                  </div>

                  <div className="text-right">
                    <p className="font-serif italic text-base text-slate-800">Vikram Malhotra</p>
                    <p className="text-[10px] text-slate-400 uppercase tracking-wider">Industry Council Chair</p>
                  </div>
                </div>

              </div>

              {/* Modal Actions */}
              <div className="flex items-center justify-between">
                <span className="text-xs text-emerald-600 font-bold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Public Verification URL Active</span>
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => window.print()}
                    className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 font-semibold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Print</span>
                  </button>
                  <button
                    onClick={() => handleDownload(activeCertificate)}
                    className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Save Official PDF</span>
                  </button>
                </div>
              </div>

            </div>
          </div>
        )}

      </main>
    </div>
  );
};
