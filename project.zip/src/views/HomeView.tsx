import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { HeroBannerCarousel } from '../components/HeroBannerCarousel';
import { AllPrograms } from '../components/AllPrograms';
import { GetStartedButton } from '../components/common/GetStartedButton';
import { CourseCard, PLACEHOLDER_COURSE_IMAGE } from '../components/CourseCard';
import {
  ProgramItem,
  getStoredPrograms,
  PROGRAMS_UPDATED_EVENT,
} from '../data/programsData';
import {
  Star,
  ArrowRight,
  ShieldCheck,
  Phone,
  Mail,
  GraduationCap,
} from 'lucide-react';

export const HomeView: React.FC = () => {
  const { navigateTo } = useApp();

  // 1. DIRECT CONNECTION TO "ALL PROGRAMS" DATA (Single source of truth)
  const [allPrograms, setAllPrograms] = useState<ProgramItem[]>(() => getStoredPrograms());
  const [selectedProgramForDetails, setSelectedProgramForDetails] = useState<ProgramItem | null>(null);

  // Sync live with Admin Panel & All Programs updates
  useEffect(() => {
    const handleSync = () => {
      setAllPrograms(getStoredPrograms());
    };
    window.addEventListener(PROGRAMS_UPDATED_EVENT, handleSync);
    window.addEventListener('storage', handleSync);
    return () => {
      window.removeEventListener(PROGRAMS_UPDATED_EVENT, handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, []);

  // 2. TOP 4 PUBLISHED COURSES FROM ALL PROGRAMS (Same order, exclude draft/unpublished/deleted)
  const top4FeaturedCourses = useMemo(() => {
    return allPrograms
      .filter((p) => (p.status || 'published') === 'published')
      .slice(0, 4);
  }, [allPrograms]);

  const handleApplyClick = (prog: ProgramItem) => {
    navigateTo('application', { selectedCourse: prog.title });
  };

  const handleChooseProgramClick = () => {
    const el = document.getElementById('all-programs-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
      navigateTo('all-programs');
    }
  };

  return (
    <div className="min-h-screen bg-white">
      
      {/* 1. HERO BANNER CAROUSEL (Directly below navbar, full width, 1920x250 promotional banner) */}
      <HeroBannerCarousel />

      {/* 2. VALUE PROPOSITION & HEADING */}
      <section className="relative z-10 overflow-hidden pt-8 pb-4 lg:pt-10 lg:pb-5 bg-gradient-to-b from-[#FAFAF8] via-[#F2F2EF] to-[#E7E7E2] shadow-[0_2px_12px_-4px_rgba(0,0,0,0.04)] border-b border-stone-200/70">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center space-y-4 flex flex-col items-center">
            
            {/* Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-[46px] font-extrabold text-slate-900 tracking-tight leading-[1.15]">
              Build Skills. Gain Experience.{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
                Launch Your Career.
              </span>
            </h1>

            {/* Subtitle */}
            <p className="subtitle text-base sm:text-lg lg:text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
              Discover internships, industry-ready courses, hands-on projects and career opportunities — all in one place.
            </p>

            {/* Prominent "Get Started" CTA Button */}
            <div className="pt-3 pb-1 flex justify-center w-full">
              <GetStartedButton />
            </div>

          </div>
        </div>
      </section>

      {/* 2.5 ALL PROGRAMS SECTION */}
      <AllPrograms />

      {/* 5. FEATURED COURSES SECTION (Directly connected to All Programs top 4 published courses) */}
      <section id="featured-courses-section" className="pt-2 sm:pt-3 lg:pt-4 pb-8 sm:pb-10 lg:pb-12 bg-slate-50/70 border-y border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* 5.1 "CHOOSE YOUR PROGRAM" FULL-WIDTH DIVIDER WITH CENTERED GOLDEN BUTTON */}
          <div className="relative w-full py-0 mb-5 sm:mb-6 flex items-center justify-center">
            {/* Thin horizontal light-gray divider line */}
            <div className="absolute inset-0 flex items-center" aria-hidden="true">
              <div className="w-full border-t border-slate-300/90" />
            </div>

            {/* Centered Golden Yellow/Mustard (#E5B52F) Rounded Rectangular Button */}
            <div className="relative flex justify-center z-10 px-3">
              <button
                type="button"
                id="choose-your-program-btn"
                onClick={handleChooseProgramClick}
                className="inline-flex items-center justify-center min-w-[200px] sm:min-w-[260px] h-[48px] sm:h-[58px] px-6 sm:px-8 rounded-[14px] font-medium text-[16px] sm:text-[18px] md:text-[19px] tracking-normal transition-all duration-200 cursor-pointer select-none active:scale-[0.98] border border-[#d8a724]"
                style={{
                  backgroundColor: '#E5B52F',
                  color: '#111827',
                  boxShadow: '0 4px 14px rgba(229, 181, 47, 0.35)',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#D9A825';
                  e.currentTarget.style.boxShadow = '0 6px 20px rgba(229, 181, 47, 0.45)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = '#E5B52F';
                  e.currentTarget.style.boxShadow = '0 4px 14px rgba(229, 181, 47, 0.35)';
                }}
              >
                Choose Your Program
              </button>
            </div>
          </div>

          {/* 
            FEATURED COURSES GRID:
            - Big Screen / Desktop / Medium (md: & lg:): Exactly 4 in ONE ROW (4 columns)
            - Mobile: 1 card per row vertically stacked
          */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 sm:gap-5 lg:gap-6">
            {top4FeaturedCourses.map((prog) => (
              <CourseCard
                key={prog.id}
                id={prog.id}
                image={prog.image}
                title={prog.title}
                category={prog.category}
                categoryLabel={prog.categoryLabel}
                branch={prog.branch}
                degreeType={prog.degreeType}
                shortDescription={prog.shortDescription}
                description={prog.description}
                duration={prog.duration}
                eligibility={prog.eligibility}
                qualification={prog.qualification || prog.eligibility}
                fee={prog.fee}
                status={prog.status || 'published'}
                badgeBg={prog.badgeBg}
                badgeBorder={prog.badgeBorder}
                badgeText={prog.badgeText}
                showAdminControls={false}
                onViewDetails={() => setSelectedProgramForDetails(prog)}
                onExploreCourse={() => setSelectedProgramForDetails(prog)}
                onApplyNow={() => handleApplyClick(prog)}
              />
            ))}
          </div>

          {/* Bottom Link to Explore Full Catalog */}
          <div className="mt-6 sm:mt-8 text-center">
            <button
              onClick={() => navigateTo('all-programs')}
              className="inline-flex items-center gap-2 px-6 py-2.5 sm:py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm rounded-xl transition-all shadow-sm hover:shadow-md cursor-pointer"
            >
              <GraduationCap className="w-4 h-4 text-blue-400" />
              <span>Explore All Engineering, Diploma & Vocational Programs</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>
      </section>

      {/* 6. HOW SKILLNEST WORKS */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="text-xs font-bold text-blue-600 uppercase tracking-wider bg-blue-50 px-2.5 py-1 rounded">
            Roadmap
          </span>
          <h2 className="text-3xl font-extrabold text-slate-900 mt-2 mb-3">
            How SkillNest Works
          </h2>
          <p className="text-sm text-slate-500 max-w-xl mx-auto mb-12">
            A seamless three-step journey to turn academic ambition into industry success.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
            <div className="p-6 rounded-2xl bg-blue-50/40 border border-blue-100 space-y-3">
              <div className="w-12 h-12 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-lg">
                1
              </div>
              <h3 className="text-lg font-bold text-slate-900">1. Upskill with Experts</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Take modular, hands-on courses covering full-stack web, data science, and design with video lessons and live mentor support.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-indigo-50/40 border border-indigo-100 space-y-3">
              <div className="w-12 h-12 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-lg">
                2
              </div>
              <h3 className="text-lg font-bold text-slate-900">2. Build Real Projects</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Complete capstone applications, submit Git repos for code review, and earn cryptographically verified credentials.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-emerald-50/40 border border-emerald-100 space-y-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-lg">
                3
              </div>
              <h3 className="text-lg font-bold text-slate-900">3. Apply & Get Hired</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Connect directly with 500+ verified corporate recruiters, track interview stages, and secure high-paying internships.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 7. STUDENT SUCCESS STORIES */}
      <section className="py-16 bg-slate-50 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold text-blue-600 uppercase tracking-wider bg-blue-50 px-2.5 py-1 rounded">
              Testimonials
            </span>
            <h2 className="text-3xl font-extrabold text-slate-900 mt-2">
              Student Success Stories
            </h2>
            <p className="text-sm text-slate-500 mt-2">
              Hear from graduates who secured roles at top technology companies.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center gap-1 text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
              </div>
              <p className="text-xs text-slate-700 leading-relaxed italic">
                "SkillNest completely transformed my campus placement preparation. The capstone project gave me concrete architecture to discuss during my Microsoft interview!"
              </p>
              <div className="flex items-center gap-3 pt-2">
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
                  alt="Student"
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div>
                  <p className="text-xs font-bold text-slate-900">Ananya Verma</p>
                  <p className="text-[10px] text-blue-600 font-medium">Software Engineer Intern @ Microsoft</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center gap-1 text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
              </div>
              <p className="text-xs text-slate-700 leading-relaxed italic">
                "The mentor feedback on my E-Commerce API was invaluable. Having a verified QR code certificate made my LinkedIn profile stand out to recruiters."
              </p>
              <div className="flex items-center gap-3 pt-2">
                <img
                  src="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=100&auto=format&fit=crop&q=80"
                  alt="Student"
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div>
                  <p className="text-xs font-bold text-slate-900">Rahul Sharma</p>
                  <p className="text-[10px] text-blue-600 font-medium">Frontend Developer Intern @ TechCorp</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center gap-1 text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
              </div>
              <p className="text-xs text-slate-700 leading-relaxed italic">
                "Applied to 3 internships through the portal and received two technical interview offers within 10 days. The direct employer pipeline actually works!"
              </p>
              <div className="flex items-center gap-3 pt-2">
                <img
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80"
                  alt="Student"
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div>
                  <p className="text-xs font-bold text-slate-900">Karan Nair</p>
                  <p className="text-[10px] text-blue-600 font-medium">Data Analyst Intern @ DataMinds</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 8. CALL TO ACTION SECTION */}
      <section className="py-16 bg-gradient-to-r from-blue-700 to-indigo-800 text-white text-center">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Ready to Launch Your Professional Career?
          </h2>
          <p className="text-base text-blue-100 max-w-xl mx-auto leading-relaxed">
            Create your student profile today, explore vetted internships, and access industry courses for free.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <GetStartedButton className="shadow-2xl" />
            <button
              onClick={() => navigateTo('all-programs')}
              className="px-6 py-3.5 bg-white text-blue-700 hover:bg-blue-50 font-bold text-sm rounded-xl shadow-lg transition-all cursor-pointer"
            >
              Explore All Programs
            </button>
            <button
              onClick={() => navigateTo('student-certificates')}
              className="px-6 py-3.5 bg-blue-600/60 hover:bg-blue-600 text-white font-semibold text-sm rounded-xl border border-blue-400/40 transition-all cursor-pointer"
            >
              Verify Certificates
            </button>
          </div>
        </div>
      </section>

      {/* ====================================================================
          COURSE DETAILS MODAL (EXPLORE COURSE MODAL)
          ==================================================================== */}
      {selectedProgramForDetails && (
        <div
          id="featured-course-details-modal"
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in"
          onClick={() => setSelectedProgramForDetails(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Top Image Banner */}
            <div className="relative aspect-[16/10] overflow-hidden rounded-t-2xl bg-slate-100">
              <img
                src={selectedProgramForDetails.image || PLACEHOLDER_COURSE_IMAGE}
                alt={selectedProgramForDetails.title}
                className="w-full h-full object-cover"
              />
              <button
                id="close-featured-course-modal-btn"
                onClick={() => setSelectedProgramForDetails(null)}
                className="absolute top-3 right-3 w-8 h-8 rounded-full bg-slate-900/70 hover:bg-slate-900 text-white flex items-center justify-center text-sm font-bold transition-colors cursor-pointer"
              >
                ✕
              </button>

              <div className="absolute bottom-3 left-3 flex items-center gap-2">
                <span className={`px-2.5 py-1 rounded-full text-xs font-bold backdrop-blur-md shadow-md ${selectedProgramForDetails.badgeBg} ${selectedProgramForDetails.badgeBorder} ${selectedProgramForDetails.badgeText} border`}>
                  {selectedProgramForDetails.categoryLabel}
                </span>
                <span className="px-2.5 py-1 rounded-md text-xs font-semibold bg-slate-900/80 text-white backdrop-blur-md">
                  {selectedProgramForDetails.branch || selectedProgramForDetails.degreeType}
                </span>
              </div>
            </div>

            <div className="p-5 sm:p-6 space-y-4">
              {/* Header Title & Credential Badge */}
              <div className="flex items-start justify-between gap-3">
                <div>
                  <span className="text-[11px] font-bold text-blue-600 uppercase tracking-wider block mb-1">
                    {selectedProgramForDetails.degreeType} Program
                  </span>
                  <h3 className="text-xl sm:text-2xl font-bold text-slate-900 leading-snug">
                    {selectedProgramForDetails.title}
                  </h3>
                </div>
                {selectedProgramForDetails.fee && (
                  <div className="text-right shrink-0">
                    <span className="text-[10px] text-slate-400 block font-bold uppercase">Course Fee</span>
                    <span className="text-base font-extrabold text-emerald-700">{selectedProgramForDetails.fee}</span>
                  </div>
                )}
              </div>

              {/* Short & Full Description */}
              <div className="space-y-2">
                {selectedProgramForDetails.shortDescription && (
                  <p className="text-xs font-semibold text-slate-600 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    {selectedProgramForDetails.shortDescription}
                  </p>
                )}
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {selectedProgramForDetails.description}
                </p>
              </div>

              {/* Key Course Specifications Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 text-xs">
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Duration</span>
                  <span className="font-semibold text-slate-800">{selectedProgramForDetails.duration}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Passing Year</span>
                  <span className="font-semibold text-slate-800">{selectedProgramForDetails.passingYear || '2023 - 2026'}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Eligibility</span>
                  <span className="font-semibold text-slate-800 line-clamp-1" title={selectedProgramForDetails.eligibility}>
                    {selectedProgramForDetails.eligibility}
                  </span>
                </div>
              </div>

              {/* Certificate Information */}
              {selectedProgramForDetails.certificateInfo && (
                <div className="flex items-start gap-2.5 p-3 bg-blue-50/70 border border-blue-200/80 rounded-xl text-xs text-blue-900">
                  <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block">Accredited Certificate:</span>
                    <span>{selectedProgramForDetails.certificateInfo}</span>
                  </div>
                </div>
              )}

              {/* Focus Areas */}
              {selectedProgramForDetails.specializations && selectedProgramForDetails.specializations.length > 0 && (
                <div>
                  <span className="text-xs font-bold text-slate-700 block mb-1.5">Core Syllabus & Focus Areas:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedProgramForDetails.specializations.map((spec, i) => (
                      <span key={i} className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg text-xs font-medium border border-slate-200">
                        {spec}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Career Opportunities */}
              {selectedProgramForDetails.careerOpportunities && selectedProgramForDetails.careerOpportunities.length > 0 && (
                <div>
                  <span className="text-xs font-bold text-slate-700 block mb-1.5">Career Opportunities & Roles:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedProgramForDetails.careerOpportunities.map((role, i) => (
                      <span key={i} className="px-2.5 py-1 bg-emerald-50 text-emerald-800 rounded-lg text-xs font-medium border border-emerald-200">
                        {role}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Counselor Contact Info */}
              {selectedProgramForDetails.contactInfo && (
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <span className="font-bold text-slate-700">Course Advisor / Helpdesk:</span>
                  <div className="flex items-center gap-3 text-slate-600">
                    {selectedProgramForDetails.contactInfo.phone && (
                      <a href={`tel:${selectedProgramForDetails.contactInfo.phone}`} className="flex items-center gap-1 hover:text-blue-600">
                        <Phone className="w-3.5 h-3.5 text-blue-600" />
                        <span>{selectedProgramForDetails.contactInfo.phone}</span>
                      </a>
                    )}
                    {selectedProgramForDetails.contactInfo.email && (
                      <a href={`mailto:${selectedProgramForDetails.contactInfo.email}`} className="flex items-center gap-1 hover:text-blue-600">
                        <Mail className="w-3.5 h-3.5 text-blue-600" />
                        <span>{selectedProgramForDetails.contactInfo.email}</span>
                      </a>
                    )}
                  </div>
                </div>
              )}

              {/* Modal Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSelectedProgramForDetails(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedProgramForDetails(null);
                    handleApplyClick(selectedProgramForDetails);
                  }}
                  className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-sm cursor-pointer"
                >
                  Apply for Admission
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
