import React, { useState, useEffect, useId, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { getStoredPrograms, ProgramItem } from '../data/programsData';
import {
  MapPin,
  Phone,
  Mail,
  Send,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  BookOpen,
  ArrowRight,
  ShieldCheck,
  Sparkles,
  GraduationCap,
  Clock,
  ExternalLink,
  ChevronDown
} from 'lucide-react';

export const ApplicationContactView: React.FC = () => {
  const {
    courses,
    contactDetails,
    addCourseInquiry,
    selectedCourseForApplication,
    setSelectedCourseForApplication,
    navigateTo,
  } = useApp();

  const [availablePrograms] = useState<ProgramItem[]>(() => getStoredPrograms());

  // Form Fields State
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [selectedCourse, setSelectedCourse] = useState('');
  const [message, setMessage] = useState('');
  const [captchaInput, setCaptchaInput] = useState('');
  
  // Captcha Generator State
  const [captchaCode, setCaptchaCode] = useState('');
  const [isCaptchaSpinning, setIsCaptchaSpinning] = useState(false);

  // Form Validation & Submission State
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showSuccessToast, setShowSuccessToast] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submittedInquiryId, setSubmittedInquiryId] = useState<string | null>(null);

  // Generate a random 6-character alphanumeric captcha
  const generateCaptcha = () => {
    setIsCaptchaSpinning(true);
    setTimeout(() => setIsCaptchaSpinning(false), 400);
    const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz';
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setCaptchaCode(code);
    setCaptchaInput('');
  };

  // Initialize Captcha & Pre-populate Selected Course on mount or change
  useEffect(() => {
    generateCaptcha();
  }, []);

  useEffect(() => {
    if (selectedCourseForApplication) {
      setSelectedCourse(selectedCourseForApplication);
      if (!subject) {
        setSubject(`Application for ${selectedCourseForApplication}`);
      }
    } else if (availablePrograms.length > 0 && !selectedCourse) {
      setSelectedCourse(availablePrograms[0].title);
      setSubject(`Application for ${availablePrograms[0].title}`);
    } else if (courses.length > 0 && !selectedCourse) {
      setSelectedCourse(courses[0].title);
      setSubject(`Application for ${courses[0].title}`);
    }
  }, [selectedCourseForApplication, availablePrograms, courses]);

  // Handle Course Selection Change
  const handleCourseChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const courseTitle = e.target.value;
    setSelectedCourse(courseTitle);
    setSelectedCourseForApplication(courseTitle);
    if (!subject || subject.startsWith('Application for ')) {
      setSubject(`Application for ${courseTitle}`);
    }
    if (errors.selectedCourse) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next.selectedCourse;
        return next;
      });
    }
  };

  // Form Validation Logic
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!name.trim()) {
      newErrors.name = 'Full Name is required.';
    } else if (name.trim().length < 2) {
      newErrors.name = 'Name must be at least 2 characters.';
    }

    if (!phone.trim()) {
      newErrors.phone = 'Phone Number is required.';
    } else {
      const cleanPhone = phone.replace(/[\s\-+()]/g, '');
      // Validate Indian phone numbers (10 digits, or prefixed with 91)
      const phoneRegex = /^(?:91)?[6789]\d{9}$/;
      if (!phoneRegex.test(cleanPhone)) {
        newErrors.phone = 'Please enter a valid 10-digit Indian phone number.';
      }
    }

    if (!email.trim()) {
      newErrors.email = 'Email Address is required.';
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email.trim())) {
        newErrors.email = 'Please enter a valid email address.';
      }
    }

    if (!subject.trim()) {
      newErrors.subject = 'Subject is required.';
    }

    if (!selectedCourse.trim()) {
      newErrors.selectedCourse = 'Please select a program/course.';
    }

    if (!message.trim()) {
      newErrors.message = 'Your message is required.';
    } else if (message.trim().length < 5) {
      newErrors.message = 'Message must be at least 5 characters.';
    }

    if (!captchaInput.trim()) {
      newErrors.captcha = 'Security code is required.';
    } else if (captchaInput.trim() !== captchaCode) {
      newErrors.captcha = 'Incorrect security code. Please try again.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Handle Form Submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    // Save to AppContext & LocalStorage
    const newInquiry = addCourseInquiry({
      name: name.trim(),
      phone: phone.trim(),
      email: email.trim().toLowerCase(),
      subject: subject.trim(),
      selectedCourse: selectedCourse.trim(),
      message: message.trim(),
    });

    setSubmittedInquiryId(newInquiry.inquiryNumber);
    setIsSubmitted(true);
    setShowSuccessToast(true);

    // Reset Form Fields
    setName('');
    setPhone('');
    setEmail('');
    setMessage('');
    setCaptchaInput('');
    generateCaptcha();

    // AUTO-HIDE SUCCESS NOTIFICATION AFTER EXACTLY 3 SECONDS
    const timer = setTimeout(() => {
      setShowSuccessToast(false);
    }, 3000);

    return () => clearTimeout(timer);
  };

  // Social Links
  const socialLinks = [
    { name: 'YouTube', icon: 'youtube', href: 'https://youtube.com', color: '#005a9c' },
    { name: 'Facebook', icon: 'facebook', href: 'https://facebook.com', color: '#005a9c' },
    { name: 'Twitter', icon: 'twitter', href: 'https://twitter.com', color: '#005a9c' },
    { name: 'Instagram', icon: 'instagram', href: 'https://instagram.com', color: '#005a9c' },
    { name: 'LinkedIn', icon: 'linkedin', href: 'https://linkedin.com', color: '#005a9c' },
  ];

  return (
    <div className="min-h-screen bg-slate-50/70 py-10 sm:py-14 px-4 sm:px-6 lg:px-8">
      {/* Light Green Success Notification (Sticky Top Banner / Floating Alert) */}
      {showSuccessToast && (
        <div
          id="application-success-notification"
          role="alert"
          className="fixed top-20 left-1/2 -translate-x-1/2 z-50 w-[92%] max-w-lg bg-emerald-50 border-2 border-emerald-400 text-emerald-950 px-5 py-4 rounded-2xl shadow-xl shadow-emerald-900/10 flex items-center gap-3.5 transition-all duration-300 animate-in fade-in slide-in-from-top-4"
        >
          <div className="w-9 h-9 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0 shadow-xs">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="text-sm font-bold text-emerald-900 leading-tight">
              Application Sent Successfully!
            </h4>
            <p className="text-xs text-emerald-800 mt-0.5 leading-relaxed">
              Your message has been sent successfully. Our academic counselor will reach out shortly.
            </p>
          </div>
        </div>
      )}

      <div className="max-w-6xl mx-auto">
        {/* Top Breadcrumb Navigation */}
        <div className="mb-6 sm:mb-8 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-500">
            <button
              onClick={() => navigateTo('home')}
              className="hover:text-blue-600 transition-colors cursor-pointer"
            >
              Home
            </button>
            <span>/</span>
            <button
              onClick={() => navigateTo('all-programs')}
              className="hover:text-blue-600 transition-colors cursor-pointer"
            >
              Academic Programs
            </button>
            <span>/</span>
            <span className="text-slate-900 font-semibold">Student Application & Contact</span>
          </div>

          <button
            onClick={() => navigateTo('all-programs')}
            className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-medium text-blue-600 hover:text-blue-700 cursor-pointer"
          >
            <span>Browse All Courses</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Main 2-Column Section Matching Screenshot */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          
          {/* =========================================================================
              LEFT COLUMN: Get In Touch
             ========================================================================= */}
          <div className="lg:col-span-5 space-y-6 sm:space-y-8">
            <div>
              <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
                Get In <span className="text-[#005a9c] text-blue-600">Touch</span>
              </h1>
              <p className="mt-3 text-sm sm:text-base text-slate-600 leading-relaxed">
                Have questions or need help? Feel free to reach out to us. We are here to assist you with your career and program enrollment needs.
              </p>
            </div>

            {/* Contact Information List */}
            <div className="space-y-5">
              
              {/* Location Card */}
              <div className="flex items-start gap-4 p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:border-blue-200 transition-colors">
                <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                  <MapPin className="w-6 h-6" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="text-sm font-bold text-slate-900">Our Location</h3>
                  <p className="text-xs sm:text-sm text-slate-600 mt-1 leading-relaxed">
                    {contactDetails?.address || 'Ram Nagar Karbigahiya, Postal Park Mithapur, Patna-800001'}
                  </p>
                </div>
              </div>

              {/* Phone Number Card */}
              <div className="flex items-start gap-4 p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:border-blue-200 transition-colors">
                <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                  <Phone className="w-6 h-6" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="text-sm font-bold text-slate-900">Phone Number</h3>
                  <div className="mt-1 space-y-0.5 text-xs sm:text-sm text-slate-600">
                    <div>
                      <a
                        href="tel:+917903328407"
                        className="hover:text-blue-600 font-medium transition-colors"
                      >
                        +91-7903328407
                      </a>
                    </div>
                    <div>
                      <a
                        href="tel:+917079767546"
                        className="hover:text-blue-600 font-medium transition-colors"
                      >
                        +91-7079767546
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              {/* Email Address Card */}
              <div className="flex items-start gap-4 p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:border-blue-200 transition-colors">
                <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                  <Mail className="w-6 h-6" />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="text-sm font-bold text-slate-900">Email Address</h3>
                  <p className="text-xs sm:text-sm text-slate-600 mt-1 break-all">
                    <a
                      href={`mailto:${contactDetails?.email || 'infozyinterntechnology@gmail.com'}`}
                      className="hover:text-blue-600 font-medium transition-colors"
                    >
                      {contactDetails?.email || 'infozyinterntechnology@gmail.com'}
                    </a>
                  </p>
                </div>
              </div>

            </div>

            {/* Social Media Circular Buttons */}
            <div className="pt-2">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
                Connect With Us
              </p>
              <div className="flex items-center gap-3">
                {/* YouTube */}
                <a
                  href="https://youtube.com"
                  target="_blank"
                  rel="noreferrer"
                  title="YouTube"
                  className="w-10 h-10 rounded-full bg-[#005a9c] hover:bg-red-600 text-white flex items-center justify-center transition-all duration-200 shadow-sm hover:scale-105 cursor-pointer"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                  </svg>
                </a>

                {/* Facebook */}
                <a
                  href="https://facebook.com"
                  target="_blank"
                  rel="noreferrer"
                  title="Facebook"
                  className="w-10 h-10 rounded-full bg-[#005a9c] hover:bg-blue-600 text-white flex items-center justify-center transition-all duration-200 shadow-sm hover:scale-105 cursor-pointer"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                  </svg>
                </a>

                {/* Twitter / X */}
                <a
                  href="https://twitter.com"
                  target="_blank"
                  rel="noreferrer"
                  title="Twitter / X"
                  className="w-10 h-10 rounded-full bg-[#005a9c] hover:bg-slate-800 text-white flex items-center justify-center transition-all duration-200 shadow-sm hover:scale-105 cursor-pointer"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                  </svg>
                </a>

                {/* Instagram */}
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noreferrer"
                  title="Instagram"
                  className="w-10 h-10 rounded-full bg-[#005a9c] hover:bg-pink-600 text-white flex items-center justify-center transition-all duration-200 shadow-sm hover:scale-105 cursor-pointer"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                  </svg>
                </a>

                {/* LinkedIn */}
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noreferrer"
                  title="LinkedIn"
                  className="w-10 h-10 rounded-full bg-[#005a9c] hover:bg-blue-700 text-white flex items-center justify-center transition-all duration-200 shadow-sm hover:scale-105 cursor-pointer"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                  </svg>
                </a>
              </div>
            </div>

            {/* Quick Assurance Box */}
            <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-100 flex items-center gap-3 text-xs text-blue-900">
              <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0" />
              <span>
                <strong>100% Privacy Assured:</strong> Your contact details and applications are directly connected to our admission portal.
              </span>
            </div>
          </div>


          {/* =========================================================================
              RIGHT COLUMN: Send us a Message (Form Card)
             ========================================================================= */}
          <div className="lg:col-span-7">
            <div className="bg-white rounded-2xl sm:rounded-3xl border border-slate-200 shadow-xl shadow-slate-200/50 p-6 sm:p-8 md:p-10">
              
              <div className="mb-6">
                <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                  Send us a Message
                </h2>
                <p className="text-xs sm:text-sm text-slate-500 mt-1">
                  Fill out the details below to apply or request more information for your selected program.
                </p>
              </div>

              {/* Success Notification Inside Card if shown */}
              {showSuccessToast && (
                <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-900 flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <div className="text-xs sm:text-sm">
                    <strong>Your message has been sent successfully!</strong>
                    {submittedInquiryId && (
                      <span className="block text-emerald-700 text-xs mt-0.5">
                        Inquiry Reference ID: {submittedInquiryId}
                      </span>
                    )}
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-5" noValidate>
                
                {/* Row 1: Your Name & Phone Number */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Field 1: Your Name */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Your Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="applicant-name-input"
                      type="text"
                      placeholder="Full Name"
                      value={name}
                      onChange={(e) => {
                        setName(e.target.value);
                        if (errors.name) {
                          setErrors((prev) => {
                            const next = { ...prev };
                            delete next.name;
                            return next;
                          });
                        }
                      }}
                      className={`w-full h-11 px-3.5 rounded-xl border text-sm text-slate-900 placeholder:text-slate-400 bg-white focus:outline-none focus:ring-2 transition-all ${
                        errors.name
                          ? 'border-red-400 focus:ring-red-400/20 bg-red-50/20'
                          : 'border-slate-300 focus:border-[#005a9c] focus:ring-[#005a9c]/20'
                      }`}
                    />
                    {errors.name && (
                      <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>{errors.name}</span>
                      </p>
                    )}
                  </div>

                  {/* Field 2: Phone Number */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Phone Number <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="applicant-phone-input"
                      type="tel"
                      placeholder="Contact Number"
                      value={phone}
                      onChange={(e) => {
                        setPhone(e.target.value);
                        if (errors.phone) {
                          setErrors((prev) => {
                            const next = { ...prev };
                            delete next.phone;
                            return next;
                          });
                        }
                      }}
                      className={`w-full h-11 px-3.5 rounded-xl border text-sm text-slate-900 placeholder:text-slate-400 bg-white focus:outline-none focus:ring-2 transition-all ${
                        errors.phone
                          ? 'border-red-400 focus:ring-red-400/20 bg-red-50/20'
                          : 'border-slate-300 focus:border-[#005a9c] focus:ring-[#005a9c]/20'
                      }`}
                    />
                    {errors.phone && (
                      <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>{errors.phone}</span>
                      </p>
                    )}
                  </div>
                </div>

                {/* Row 2: Email Address & Subject */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Field 3: Email Address */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Email Address <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="applicant-email-input"
                      type="email"
                      placeholder="Email"
                      value={email}
                      onChange={(e) => {
                        setEmail(e.target.value);
                        if (errors.email) {
                          setErrors((prev) => {
                            const next = { ...prev };
                            delete next.email;
                            return next;
                          });
                        }
                      }}
                      className={`w-full h-11 px-3.5 rounded-xl border text-sm text-slate-900 placeholder:text-slate-400 bg-white focus:outline-none focus:ring-2 transition-all ${
                        errors.email
                          ? 'border-red-400 focus:ring-red-400/20 bg-red-50/20'
                          : 'border-slate-300 focus:border-[#005a9c] focus:ring-[#005a9c]/20'
                      }`}
                    />
                    {errors.email && (
                      <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>{errors.email}</span>
                      </p>
                    )}
                  </div>

                  {/* Field 4: Subject */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Subject <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="applicant-subject-input"
                      type="text"
                      placeholder="Reason for contact"
                      value={subject}
                      onChange={(e) => {
                        setSubject(e.target.value);
                        if (errors.subject) {
                          setErrors((prev) => {
                            const next = { ...prev };
                            delete next.subject;
                            return next;
                          });
                        }
                      }}
                      className={`w-full h-11 px-3.5 rounded-xl border text-sm text-slate-900 placeholder:text-slate-400 bg-white focus:outline-none focus:ring-2 transition-all ${
                        errors.subject
                          ? 'border-red-400 focus:ring-red-400/20 bg-red-50/20'
                          : 'border-slate-300 focus:border-[#005a9c] focus:ring-[#005a9c]/20'
                      }`}
                    />
                    {errors.subject && (
                      <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>{errors.subject}</span>
                      </p>
                    )}
                  </div>
                </div>

                {/* Row 3: Selected Program / Course (Automatic Carry Over from Apply Button) */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-xs font-semibold text-slate-700">
                      Selected Program / Course <span className="text-red-500">*</span>
                    </label>
                    {selectedCourse && (
                      <span className="text-[11px] font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200/80">
                        ✓ Selected for application
                      </span>
                    )}
                  </div>
                  <div className="relative">
                    <select
                      id="applicant-course-select"
                      value={selectedCourse}
                      onChange={handleCourseChange}
                      className={`w-full h-11 px-3.5 pr-10 rounded-xl border text-sm text-slate-900 bg-white focus:outline-none focus:ring-2 appearance-none transition-all cursor-pointer ${
                        errors.selectedCourse
                          ? 'border-red-400 focus:ring-red-400/20 bg-red-50/20'
                          : 'border-slate-300 focus:border-[#005a9c] focus:ring-[#005a9c]/20'
                      }`}
                    >
                      <option value="" disabled hidden>-- Select a Program / Course --</option>
                      {availablePrograms.map((prog) => (
                        <option key={prog.id} value={prog.title}>
                          {prog.title} ({prog.categoryLabel || prog.degreeType})
                        </option>
                      ))}
                      {/* Allow custom program if not in list */}
                      {selectedCourse && !availablePrograms.some((c) => c.title === selectedCourse) && (
                        <option value={selectedCourse}>
                          {selectedCourse} (Selected Program)
                        </option>
                      )}
                    </select>
                    <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                  </div>
                  {errors.selectedCourse && (
                    <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{errors.selectedCourse}</span>
                    </p>
                  )}
                </div>

                {/* Row 4: Your Message */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Your Message <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    id="applicant-message-input"
                    rows={4}
                    placeholder="Write your message here..."
                    value={message}
                    onChange={(e) => {
                      setMessage(e.target.value);
                      if (errors.message) {
                        setErrors((prev) => {
                          const next = { ...prev };
                          delete next.message;
                          return next;
                        });
                      }
                    }}
                    className={`w-full p-3.5 rounded-xl border text-sm text-slate-900 placeholder:text-slate-400 bg-white focus:outline-none focus:ring-2 resize-y min-h-[100px] transition-all ${
                      errors.message
                        ? 'border-red-400 focus:ring-red-400/20 bg-red-50/20'
                        : 'border-slate-300 focus:border-[#005a9c] focus:ring-[#005a9c]/20'
                    }`}
                  />
                  {errors.message && (
                    <p className="text-xs text-red-600 mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{errors.message}</span>
                    </p>
                  )}
                </div>

                {/* Row 5: Security Code * (Captcha) and Send Button */}
                <div className="pt-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Security Code <span className="text-red-500">*</span>
                  </label>

                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
                    
                    {/* Captcha Display with stylized monospace & refresh button */}
                    <div className="sm:col-span-4 flex items-center justify-between bg-slate-100 border border-slate-300 rounded-xl px-3 py-2 select-none h-11">
                      <span
                        className="font-mono font-black text-lg tracking-widest text-slate-800 italic"
                        style={{
                          letterSpacing: '0.25em',
                          textShadow: '1px 1px 1px rgba(0,0,0,0.15)',
                        }}
                      >
                        {captchaCode}
                      </span>
                      <button
                        type="button"
                        onClick={generateCaptcha}
                        title="Generate new security code"
                        className="text-slate-500 hover:text-blue-600 p-1 rounded-md hover:bg-slate-200 transition-colors cursor-pointer"
                      >
                        <RefreshCw className={`w-4 h-4 ${isCaptchaSpinning ? 'animate-spin' : ''}`} />
                      </button>
                    </div>

                    {/* Enter Code Input */}
                    <div className="sm:col-span-5">
                      <input
                        id="applicant-captcha-input"
                        type="text"
                        placeholder="Enter code"
                        value={captchaInput}
                        onChange={(e) => {
                          setCaptchaInput(e.target.value);
                          if (errors.captcha) {
                            setErrors((prev) => {
                              const next = { ...prev };
                              delete next.captcha;
                              return next;
                            });
                          }
                        }}
                        className={`w-full h-11 px-3.5 rounded-xl border text-sm text-slate-900 placeholder:text-slate-400 bg-white focus:outline-none focus:ring-2 transition-all ${
                          errors.captcha
                            ? 'border-red-400 focus:ring-red-400/20 bg-red-50/20'
                            : 'border-slate-300 focus:border-[#005a9c] focus:ring-[#005a9c]/20'
                        }`}
                      />
                    </div>

                    {/* Send Button */}
                    <div className="sm:col-span-3">
                      <button
                        id="application-submit-button"
                        type="submit"
                        disabled={showSuccessToast}
                        className={`w-full h-11 px-4 bg-[#005a9c] hover:bg-blue-700 active:bg-blue-800 text-white text-sm font-semibold rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all duration-200 cursor-pointer ${
                          showSuccessToast ? 'opacity-60 cursor-not-allowed bg-emerald-600' : ''
                        }`}
                      >
                        {showSuccessToast ? (
                          <>
                            <CheckCircle2 className="w-4 h-4" />
                            <span>Sent!</span>
                          </>
                        ) : (
                          <>
                            <Send className="w-4 h-4" />
                            <span>Send</span>
                          </>
                        )}
                      </button>
                    </div>

                  </div>

                  {errors.captcha && (
                    <p className="text-xs text-red-600 mt-1.5 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{errors.captcha}</span>
                    </p>
                  )}
                </div>

              </form>

            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
