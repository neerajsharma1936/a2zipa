import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StudentRegistration, StudentRegistrationStatus, CourseInquiry } from '../../types';
import {
  Users,
  Search,
  Filter,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  FileText,
  ShieldCheck,
  FileCheck,
  ExternalLink,
  Download,
  AlertCircle,
  Eye,
  Settings,
  GraduationCap,
  Briefcase,
  Building2,
  Calendar,
  Layers,
  ChevronRight,
  MoreVertical,
  CheckCircle2,
  Clock,
  XCircle,
  Award,
  Inbox,
  Mail,
  Phone,
  MessageSquare,
  MessageCircle,
  Send
} from 'lucide-react';

export const StudentRegistrationsManagement: React.FC = () => {
  const {
    studentRegistrations,
    updateRegistrationStatus,
    deleteRegistration,
    courseInquiries,
    updateCourseInquiryStatus,
    deleteCourseInquiry,
    placements,
    addPlacement,
    updatePlacement,
    removePlacement,
    qualifications,
    addQualification,
    updateQualification,
    removeQualification,
    branchesList,
    addBranchOption,
    updateBranchOption,
    removeBranchOption,
    passingYears,
    addPassingYear,
    removePassingYear,
    colleges,
    addCollege,
    updateCollege,
    removeCollege,
    showToast,
  } = useApp();

  // Active Admin Sub-Tab
  const [activeTab, setActiveTab] = useState<'inquiries' | 'registrations' | 'form-options'>('inquiries');

  // Inquiries Filter & Search
  const [inquirySearch, setInquirySearch] = useState('');
  const [inquiryStatusFilter, setInquiryStatusFilter] = useState<string>('All');
  const [selectedInquiry, setSelectedInquiry] = useState<CourseInquiry | null>(null);

  // Registrations Filter & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [selectedPlacementFilter, setSelectedPlacementFilter] = useState<string>('All');
  const [selectedRegistration, setSelectedRegistration] = useState<StudentRegistration | null>(null);

  // Status Modal Edit
  const [statusModalOpen, setStatusModalOpen] = useState(false);
  const [editingRegistration, setEditingRegistration] = useState<StudentRegistration | null>(null);
  const [newStatus, setNewStatus] = useState<StudentRegistrationStatus>('Pending');
  const [adminRemarks, setAdminRemarks] = useState('');

  // Form Options Editing States
  const [newPlacementInput, setNewPlacementInput] = useState('');
  const [editingPlacement, setEditingPlacement] = useState<{ original: string; current: string } | null>(null);

  const [newQualInput, setNewQualInput] = useState('');
  const [editingQual, setEditingQual] = useState<{ original: string; current: string } | null>(null);

  const [newBranchInput, setNewBranchInput] = useState('');
  const [editingBranch, setEditingBranch] = useState<{ original: string; current: string } | null>(null);

  const [newYearInput, setNewYearInput] = useState('');

  const [newCollegeInput, setNewCollegeInput] = useState('');
  const [editingCollege, setEditingCollege] = useState<{ original: string; current: string } | null>(null);
  const [collegeSearchFilter, setCollegeSearchFilter] = useState('');

  // Filtered Registrations
  const filteredRegistrations = studentRegistrations.filter((reg) => {
    const matchesSearch =
      reg.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      reg.registrationNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      reg.college.toLowerCase().includes(searchQuery.toLowerCase()) ||
      reg.branch.toLowerCase().includes(searchQuery.toLowerCase()) ||
      reg.placement.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'All' || reg.status === statusFilter;
    const matchesPlacement = selectedPlacementFilter === 'All' || reg.placement === selectedPlacementFilter;

    return matchesSearch && matchesStatus && matchesPlacement;
  });

  // Filtered Inquiries
  const filteredInquiries = courseInquiries.filter((inq) => {
    const matchesSearch =
      inq.name.toLowerCase().includes(inquirySearch.toLowerCase()) ||
      inq.inquiryNumber.toLowerCase().includes(inquirySearch.toLowerCase()) ||
      inq.email.toLowerCase().includes(inquirySearch.toLowerCase()) ||
      inq.phone.toLowerCase().includes(inquirySearch.toLowerCase()) ||
      inq.selectedCourse.toLowerCase().includes(inquirySearch.toLowerCase()) ||
      inq.subject.toLowerCase().includes(inquirySearch.toLowerCase());

    const matchesStatus = inquiryStatusFilter === 'All' || inq.status === inquiryStatusFilter;

    return matchesSearch && matchesStatus;
  });

  const getCleanPhoneForUrl = (phoneStr: string) => {
    if (!phoneStr) return '';
    const digitsOnly = phoneStr.replace(/\D/g, '');
    if (digitsOnly.length === 10) {
      return `91${digitsOnly}`;
    }
    return digitsOnly;
  };

  const getWhatsAppUrl = (phoneStr: string, name: string, courseTitle?: string) => {
    const cleaned = getCleanPhoneForUrl(phoneStr);
    if (!cleaned) return '#';
    const text = `Hi ${name || 'there'}, thank you for reaching out to SkillNest regarding ${courseTitle ? `the ${courseTitle} program` : 'our courses'}! How can our academic counselors assist you today with admission & syllabus details?`;
    return `https://wa.me/${cleaned}?text=${encodeURIComponent(text)}`;
  };

  const getEmailUrl = (emailStr: string, name: string, courseTitle?: string) => {
    if (!emailStr) return '#';
    const subject = `SkillNest Admission & Syllabus Details - ${courseTitle || 'Your Program Inquiry'}`;
    const body = `Hi ${name || 'there'},\n\nThank you for reaching out to SkillNest.\n\nWe received your inquiry regarding ${courseTitle ? `the "${courseTitle}" course` : 'our programs'}. Our academic counseling team is available to help you with curriculum, batch schedules, fees, and internship certifications.\n\nPlease feel free to reply to this email or reach us directly.\n\nBest regards,\nSkillNest Academic Admissions Team`;
    return `mailto:${emailStr}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  const getInquiryStatusBadge = (status: CourseInquiry['status']) => {
    switch (status) {
      case 'Enrolled':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold rounded-full">
            <CheckCircle2 className="w-3 h-3" /> Enrolled
          </span>
        );
      case 'Contacted':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-blue-50 text-blue-700 border border-blue-200 text-xs font-bold rounded-full">
            <Phone className="w-3 h-3" /> Contacted
          </span>
        );
      case 'Closed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-slate-100 text-slate-600 border border-slate-200 text-xs font-bold rounded-full">
            <XCircle className="w-3 h-3" /> Closed
          </span>
        );
      case 'New':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 text-xs font-bold rounded-full">
            <Clock className="w-3 h-3" /> New
          </span>
        );
    }
  };

  const handleExportInquiriesCSV = () => {
    if (filteredInquiries.length === 0) {
      showToast('No inquiries found to export', 'error');
      return;
    }

    const headers = ['Inquiry ID', 'Name', 'Phone', 'Email', 'Selected Course', 'Subject', 'Message', 'Status', 'Submitted Date'];
    const rows = filteredInquiries.map((inq) => [
      inq.inquiryNumber,
      `"${inq.name.replace(/"/g, '""')}"`,
      `"${inq.phone}"`,
      `"${inq.email}"`,
      `"${inq.selectedCourse.replace(/"/g, '""')}"`,
      `"${inq.subject.replace(/"/g, '""')}"`,
      `"${inq.message.replace(/"/g, '""')}"`,
      inq.status,
      new Date(inq.createdAt).toLocaleDateString(),
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `SkillNest_Course_Inquiries_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Exported course inquiries CSV', 'success');
  };

  const getStatusBadge = (status: StudentRegistrationStatus) => {
    switch (status) {
      case 'Approved':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-bold rounded-full">
            <CheckCircle2 className="w-3.5 h-3.5" /> Approved
          </span>
        );
      case 'Shortlisted':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-blue-50 text-blue-700 border border-blue-200 text-xs font-bold rounded-full">
            <Award className="w-3.5 h-3.5" /> Shortlisted
          </span>
        );
      case 'Under Review':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-purple-50 text-purple-700 border border-purple-200 text-xs font-bold rounded-full">
            <Clock className="w-3.5 h-3.5" /> Under Review
          </span>
        );
      case 'Rejected':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-rose-50 text-rose-700 border border-rose-200 text-xs font-bold rounded-full">
            <XCircle className="w-3.5 h-3.5" /> Rejected
          </span>
        );
      case 'Pending':
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-amber-50 text-amber-700 border border-amber-200 text-xs font-bold rounded-full">
            <Clock className="w-3.5 h-3.5" /> Pending
          </span>
        );
    }
  };

  const handleOpenStatusModal = (reg: StudentRegistration) => {
    setEditingRegistration(reg);
    setNewStatus(reg.status);
    setAdminRemarks(reg.adminRemarks || '');
    setStatusModalOpen(true);
  };

  const handleSaveStatus = () => {
    if (!editingRegistration) return;
    updateRegistrationStatus(editingRegistration.id, newStatus, adminRemarks);
    setStatusModalOpen(false);
    if (selectedRegistration?.id === editingRegistration.id) {
      setSelectedRegistration((prev) => (prev ? { ...prev, status: newStatus, adminRemarks } : null));
    }
  };

  const handleExportCSV = () => {
    if (filteredRegistrations.length === 0) {
      showToast('No registrations to export', 'info');
      return;
    }

    const headers = [
      'Registration Number',
      'Name',
      'Placement',
      'Qualification',
      'Branch',
      'College',
      'Passing Year',
      'Email',
      'Phone',
      'Status',
      'Submitted Date',
    ];

    const rows = filteredRegistrations.map((r) => [
      `"${r.registrationNumber}"`,
      `"${r.name}"`,
      `"${r.placement}"`,
      `"${r.qualification}"`,
      `"${r.branch}"`,
      `"${r.college}"`,
      `"${r.passingYear}"`,
      `"${r.email || ''}"`,
      `"${r.phone || ''}"`,
      `"${r.status}"`,
      `"${new Date(r.submittedAt).toLocaleDateString()}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `SkillNest_Student_Registrations_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Exported registrations CSV', 'success');
  };

  return (
    <div className="space-y-6">
      
      {/* Top Header & Tab Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 flex items-center gap-2.5">
            <Users className="w-6 h-6 text-orange-600" />
            Student Registrations & Form Options
          </h1>
          <p className="text-slate-500 text-xs sm:text-sm mt-1">
            Manage incoming student registration submissions, verify documents, and customize form dropdown options.
          </p>
        </div>

        <div className="flex items-center gap-2 p-1 bg-slate-100 rounded-xl flex-wrap">
          <button
            id="tab-inquiries-list"
            onClick={() => setActiveTab('inquiries')}
            className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-all cursor-pointer ${
              activeTab === 'inquiries'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Course Inquiries & Applications ({courseInquiries.length})
          </button>
          <button
            id="tab-registrations-list"
            onClick={() => setActiveTab('registrations')}
            className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-all cursor-pointer ${
              activeTab === 'registrations'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Full Registrations ({studentRegistrations.length})
          </button>
          <button
            id="tab-form-options"
            onClick={() => setActiveTab('form-options')}
            className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-all cursor-pointer ${
              activeTab === 'form-options'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Form Dropdown Options
          </button>
        </div>
      </div>

      {/* =======================================================================
          TAB 0: COURSE INQUIRIES & APPLICATIONS (From Application / Contact Form)
          ======================================================================= */}
      {activeTab === 'inquiries' && (
        <div className="space-y-6">
          {/* Filters and Search Bar */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col lg:flex-row gap-4 items-stretch lg:items-center justify-between">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                id="search-inquiries-input"
                type="text"
                placeholder="Search inquiries by name, course, phone, email, subject, ID..."
                value={inquirySearch}
                onChange={(e) => setInquirySearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:bg-white focus:ring-2 focus:ring-blue-100 focus:border-blue-600 transition-all"
              />
            </div>

            <div className="flex flex-wrap items-center gap-3">
              {/* Status Filter */}
              <select
                id="filter-inquiry-status"
                value={inquiryStatusFilter}
                onChange={(e) => setInquiryStatusFilter(e.target.value)}
                className="px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-700 focus:outline-none focus:bg-white cursor-pointer"
              >
                <option value="All">All Statuses</option>
                <option value="New">New</option>
                <option value="Contacted">Contacted</option>
                <option value="Enrolled">Enrolled</option>
                <option value="Closed">Closed</option>
              </select>

              {/* Export CSV Button */}
              <button
                id="btn-export-inquiries-csv"
                onClick={handleExportInquiriesCSV}
                className="px-3.5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Export CSV</span>
              </button>
            </div>
          </div>

          {/* Inquiries Table */}
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-semibold text-[11px] uppercase tracking-wider">
                    <th className="py-3.5 px-4">Applicant & ID</th>
                    <th className="py-3.5 px-4">Selected Program / Course</th>
                    <th className="py-3.5 px-4">Contact Info</th>
                    <th className="py-3.5 px-4">Subject & Message</th>
                    <th className="py-3.5 px-4">Status</th>
                    <th className="py-3.5 px-4">Date</th>
                    <th className="py-3.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredInquiries.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-12 text-center text-slate-400">
                        <Inbox className="w-10 h-10 mx-auto mb-2 opacity-40" />
                        <p className="font-semibold text-slate-600">No applications or inquiries found</p>
                        <p className="text-xs text-slate-400 mt-0.5">
                          When users click Apply on courses or submit the application form, submissions appear here.
                        </p>
                      </td>
                    </tr>
                  ) : (
                    filteredInquiries.map((inq) => (
                      <tr key={inq.id} className="hover:bg-slate-50/60 transition-colors">
                        <td className="py-3.5 px-4">
                          <div className="font-bold text-slate-900">{inq.name}</div>
                          <div className="text-[11px] font-mono text-slate-400 mt-0.5">{inq.inquiryNumber}</div>
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-semibold bg-blue-50 text-blue-800 border border-blue-100">
                            {inq.selectedCourse}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 min-w-[220px]">
                          <div className="space-y-1.5">
                            {/* Contact Details Text Links */}
                            <div className="space-y-0.5">
                              {inq.phone && (
                                <a
                                  href={`tel:${inq.phone}`}
                                  className="flex items-center gap-1.5 text-xs font-bold text-slate-800 hover:text-blue-600 transition-colors"
                                  title="Click to Call"
                                >
                                  <Phone className="w-3 h-3 text-slate-400 shrink-0" />
                                  <span>{inq.phone}</span>
                                </a>
                              )}
                              {inq.email && (
                                <a
                                  href={getEmailUrl(inq.email, inq.name, inq.selectedCourse)}
                                  className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-blue-600 transition-colors truncate max-w-[200px]"
                                  title="Click to Email"
                                >
                                  <Mail className="w-3 h-3 text-slate-400 shrink-0" />
                                  <span className="truncate">{inq.email}</span>
                                </a>
                              )}
                            </div>

                            {/* Direct Action Buttons: 📞 Call | 💬 WhatsApp | ✉️ Email */}
                            <div className="flex items-center gap-1.5 pt-1">
                              {inq.phone && (
                                <>
                                  <a
                                    href={`tel:${inq.phone}`}
                                    className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 hover:text-blue-800 border border-blue-200/80 rounded-lg text-[11px] font-bold transition-all shadow-2xs cursor-pointer"
                                    title={`Direct Phone Call to ${inq.name}`}
                                  >
                                    <Phone className="w-3 h-3 text-blue-600" />
                                    <span>Call</span>
                                  </a>

                                  <a
                                    href={getWhatsAppUrl(inq.phone, inq.name, inq.selectedCourse)}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 hover:text-emerald-800 border border-emerald-200/80 rounded-lg text-[11px] font-bold transition-all shadow-2xs cursor-pointer"
                                    title={`Send WhatsApp message to ${inq.name}`}
                                  >
                                    <MessageCircle className="w-3 h-3 text-emerald-600" />
                                    <span>WhatsApp</span>
                                  </a>
                                </>
                              )}

                              {inq.email && (
                                <a
                                  href={getEmailUrl(inq.email, inq.name, inq.selectedCourse)}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 hover:text-indigo-800 border border-indigo-200/80 rounded-lg text-[11px] font-bold transition-all shadow-2xs cursor-pointer"
                                  title={`Send Email to ${inq.email}`}
                                >
                                  <Mail className="w-3 h-3 text-indigo-600" />
                                  <span>Email</span>
                                </a>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="py-3.5 px-4 max-w-xs">
                          <div className="font-semibold text-slate-800 truncate">{inq.subject}</div>
                          <div className="text-xs text-slate-500 line-clamp-1 mt-0.5">{inq.message}</div>
                        </td>
                        <td className="py-3.5 px-4">
                          <select
                            value={inq.status}
                            onChange={(e) => updateCourseInquiryStatus(inq.id, e.target.value as CourseInquiry['status'])}
                            className="text-xs font-semibold rounded-lg px-2 py-1 bg-white border border-slate-200 cursor-pointer focus:outline-none focus:ring-1 focus:ring-blue-500"
                          >
                            <option value="New">New</option>
                            <option value="Contacted">Contacted</option>
                            <option value="Enrolled">Enrolled</option>
                            <option value="Closed">Closed</option>
                          </select>
                        </td>
                        <td className="py-3.5 px-4 text-xs text-slate-500 whitespace-nowrap">
                          {new Date(inq.createdAt).toLocaleDateString()}
                        </td>
                        <td className="py-3.5 px-4 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => setSelectedInquiry(inq)}
                              className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                              title="View Full Inquiry"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => deleteCourseInquiry(inq.id)}
                              className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                              title="Delete Inquiry"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Inquiry Detail Modal */}
          {selectedInquiry && (
            <div
              className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in"
              onClick={() => setSelectedInquiry(null)}
            >
              <div
                className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <div>
                    <span className="text-[11px] font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                      {selectedInquiry.inquiryNumber}
                    </span>
                    <h3 className="text-lg font-bold text-slate-900 mt-1">
                      {selectedInquiry.name}
                    </h3>
                  </div>
                  <button
                    onClick={() => setSelectedInquiry(null)}
                    className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="py-4 space-y-3.5 text-xs sm:text-sm">
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                      Selected Course / Program
                    </span>
                    <span className="font-bold text-blue-700 text-sm">
                      {selectedInquiry.selectedCourse}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[11px] font-bold text-slate-400 uppercase block mb-0.5">Phone</span>
                      <a href={`tel:${selectedInquiry.phone}`} className="font-bold text-slate-800 hover:text-blue-600">
                        {selectedInquiry.phone}
                      </a>
                    </div>
                    <div>
                      <span className="text-[11px] font-bold text-slate-400 uppercase block mb-0.5">Email</span>
                      <a href={`mailto:${selectedInquiry.email}`} className="font-bold text-slate-800 hover:text-blue-600 break-all">
                        {selectedInquiry.email}
                      </a>
                    </div>
                  </div>

                  {/* Direct Contact Options */}
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                      Direct Communication Options
                    </span>
                    <div className="flex flex-wrap items-center gap-2">
                      {selectedInquiry.phone && (
                        <a
                          href={`tel:${selectedInquiry.phone}`}
                          className="inline-flex items-center gap-1.5 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
                        >
                          <Phone className="w-3.5 h-3.5" />
                          <span>Direct Call</span>
                        </a>
                      )}
                      {selectedInquiry.phone && (
                        <a
                          href={getWhatsAppUrl(selectedInquiry.phone, selectedInquiry.name, selectedInquiry.selectedCourse)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>WhatsApp Message</span>
                        </a>
                      )}
                      {selectedInquiry.email && (
                        <a
                          href={getEmailUrl(selectedInquiry.email, selectedInquiry.name, selectedInquiry.selectedCourse)}
                          className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
                        >
                          <Mail className="w-3.5 h-3.5" />
                          <span>Send Email</span>
                        </a>
                      )}
                    </div>
                  </div>

                  <div>
                    <span className="text-[11px] font-bold text-slate-400 uppercase block mb-0.5">Subject</span>
                    <p className="font-medium text-slate-800">{selectedInquiry.subject}</p>
                  </div>

                  <div>
                    <span className="text-[11px] font-bold text-slate-400 uppercase block mb-0.5">Applicant Message</span>
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 text-slate-700 leading-relaxed max-h-40 overflow-y-auto">
                      {selectedInquiry.message}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <span className="text-xs text-slate-400">
                      Received: {new Date(selectedInquiry.createdAt).toLocaleString()}
                    </span>
                    <div>
                      {getInquiryStatusBadge(selectedInquiry.status)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
                  <button
                    onClick={() => {
                      updateCourseInquiryStatus(selectedInquiry.id, 'Contacted');
                      setSelectedInquiry((prev) => (prev ? { ...prev, status: 'Contacted' } : null));
                    }}
                    className="px-3.5 py-2 bg-blue-50 text-blue-700 font-semibold rounded-xl text-xs hover:bg-blue-100 transition-colors"
                  >
                    Mark as Contacted
                  </button>
                  <button
                    onClick={() => {
                      updateCourseInquiryStatus(selectedInquiry.id, 'Enrolled');
                      setSelectedInquiry((prev) => (prev ? { ...prev, status: 'Enrolled' } : null));
                    }}
                    className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs transition-colors"
                  >
                    Mark as Enrolled
                  </button>
                  <button
                    onClick={() => setSelectedInquiry(null)}
                    className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* =======================================================================
          TAB 1: STUDENT REGISTRATIONS LIST & VERIFICATION
          ======================================================================= */}
      {activeTab === 'registrations' && (
        <div className="space-y-6">
          
          {/* Filters and Search Bar */}
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col lg:flex-row gap-4 items-stretch lg:items-center justify-between">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                id="search-registrations-input"
                type="text"
                placeholder="Search by student name, reg #, college, branch, placement..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:bg-white focus:ring-2 focus:ring-blue-100 focus:border-blue-600 transition-all"
              />
            </div>

            <div className="flex flex-wrap items-center gap-3">
              {/* Status Filter */}
              <select
                id="filter-registration-status"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-700 focus:outline-none focus:bg-white cursor-pointer"
              >
                <option value="All">All Statuses</option>
                <option value="Pending">Pending</option>
                <option value="Under Review">Under Review</option>
                <option value="Shortlisted">Shortlisted</option>
                <option value="Approved">Approved</option>
                <option value="Rejected">Rejected</option>
              </select>

              {/* Placement Filter */}
              <select
                id="filter-registration-placement"
                value={selectedPlacementFilter}
                onChange={(e) => setSelectedPlacementFilter(e.target.value)}
                className="px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-700 focus:outline-none focus:bg-white cursor-pointer max-w-[200px] truncate"
              >
                <option value="All">All Placements</option>
                {placements.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>

              {/* Export CSV Button */}
              <button
                id="btn-export-registrations-csv"
                onClick={handleExportCSV}
                className="px-3.5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Export CSV</span>
              </button>
            </div>
          </div>

          {/* Registrations Table */}
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold uppercase tracking-wider text-slate-500">
                    <th className="px-5 py-4">Reg # & Date</th>
                    <th className="px-5 py-4">Student Name</th>
                    <th className="px-5 py-4">Placement Opportunity</th>
                    <th className="px-5 py-4">Qualification & Branch</th>
                    <th className="px-5 py-4">College</th>
                    <th className="px-5 py-4">Status</th>
                    <th className="px-5 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredRegistrations.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center py-12 text-slate-400">
                        <Users className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                        <p className="font-semibold">No student registrations found</p>
                        <p className="text-xs text-slate-400 mt-1">Try clearing filters or search query.</p>
                      </td>
                    </tr>
                  ) : (
                    filteredRegistrations.map((reg) => (
                      <tr key={reg.id} className="hover:bg-slate-50/60 transition-colors">
                        <td className="px-5 py-4">
                          <span className="font-mono font-bold text-slate-900 block text-xs">
                            {reg.registrationNumber}
                          </span>
                          <span className="text-[11px] text-slate-400">
                            {new Date(reg.submittedAt).toLocaleDateString()}
                          </span>
                        </td>

                        <td className="px-5 py-4">
                          <span className="font-bold text-slate-900 block">{reg.name}</span>
                          <div className="space-y-0.5 mt-0.5">
                            {reg.phone && (
                              <a
                                href={`tel:${reg.phone}`}
                                className="flex items-center gap-1 text-xs text-slate-600 hover:text-blue-600 font-medium"
                              >
                                <Phone className="w-3 h-3 text-slate-400" />
                                {reg.phone}
                              </a>
                            )}
                            {reg.email && (
                              <a
                                href={getEmailUrl(reg.email, reg.name, reg.placement)}
                                className="flex items-center gap-1 text-xs text-slate-500 hover:text-blue-600 truncate max-w-[180px]"
                              >
                                <Mail className="w-3 h-3 text-slate-400" />
                                <span className="truncate">{reg.email}</span>
                              </a>
                            )}
                          </div>
                          {(reg.phone || reg.email) && (
                            <div className="flex items-center gap-1 mt-1.5">
                              {reg.phone && (
                                <>
                                  <a
                                    href={`tel:${reg.phone}`}
                                    className="p-1 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-md text-[10px] font-bold flex items-center gap-0.5 border border-blue-200/80 cursor-pointer"
                                    title={`Call ${reg.name}`}
                                  >
                                    <Phone className="w-2.5 h-2.5" /> Call
                                  </a>
                                  <a
                                    href={getWhatsAppUrl(reg.phone, reg.name, reg.placement)}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="p-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-md text-[10px] font-bold flex items-center gap-0.5 border border-emerald-200/80 cursor-pointer"
                                    title={`WhatsApp ${reg.name}`}
                                  >
                                    <MessageCircle className="w-2.5 h-2.5" /> WhatsApp
                                  </a>
                                </>
                              )}
                              {reg.email && (
                                <a
                                  href={getEmailUrl(reg.email, reg.name, reg.placement)}
                                  className="p-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-md text-[10px] font-bold flex items-center gap-0.5 border border-indigo-200/80 cursor-pointer"
                                  title={`Email ${reg.name}`}
                                >
                                  <Mail className="w-2.5 h-2.5" /> Email
                                </a>
                              )}
                            </div>
                          )}
                        </td>

                        <td className="px-5 py-4">
                          <span className="px-2.5 py-1 bg-orange-50 text-orange-800 border border-orange-200/60 rounded-md text-xs font-medium inline-block max-w-[220px] truncate">
                            {reg.placement}
                          </span>
                        </td>

                        <td className="px-5 py-4">
                          <span className="font-semibold text-slate-800 block text-xs">
                            {reg.qualification} ({reg.passingYear})
                          </span>
                          <span className="text-xs text-slate-500 block max-w-[180px] truncate">
                            {reg.branch}
                          </span>
                        </td>

                        <td className="px-5 py-4">
                          <span className="text-xs text-slate-700 block max-w-[180px] truncate" title={reg.college}>
                            {reg.college}
                          </span>
                        </td>

                        <td className="px-5 py-4">
                          {getStatusBadge(reg.status)}
                        </td>

                        <td className="px-5 py-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              id={`btn-view-reg-${reg.id}`}
                              onClick={() => setSelectedRegistration(reg)}
                              className="p-1.5 hover:bg-slate-100 text-slate-600 hover:text-blue-600 rounded-lg transition-colors cursor-pointer"
                              title="View full submission & documents"
                            >
                              <Eye className="w-4 h-4" />
                            </button>

                            <button
                              id={`btn-status-reg-${reg.id}`}
                              onClick={() => handleOpenStatusModal(reg)}
                              className="p-1.5 hover:bg-slate-100 text-slate-600 hover:text-amber-600 rounded-lg transition-colors cursor-pointer"
                              title="Update Status / Remarks"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>

                            <button
                              id={`btn-delete-reg-${reg.id}`}
                              onClick={() => {
                                deleteRegistration(reg.id);
                              }}
                              className="p-1.5 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                              title="Delete registration"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* =======================================================================
          TAB 2: DYNAMIC FORM DROPDOWN OPTIONS MANAGEMENT
          ======================================================================= */}
      {activeTab === 'form-options' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* OPTION 1: PLACEMENTS LIST */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="font-bold text-slate-900 flex items-center gap-2">
                  <Briefcase className="w-4 h-4 text-orange-600" />
                  1. Placement Tracks
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Available in the "Placement" dropdown on the registration form.
                </p>
              </div>
              <span className="px-2.5 py-0.5 bg-orange-100 text-orange-800 text-xs font-bold rounded-full">
                {placements.length}
              </span>
            </div>

            {/* Add New Placement Input */}
            <div className="flex gap-2">
              <input
                type="text"
                value={newPlacementInput}
                onChange={(e) => setNewPlacementInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && newPlacementInput.trim()) {
                    addPlacement(newPlacementInput);
                    setNewPlacementInput('');
                  }
                }}
                placeholder="Add new placement opportunity..."
                className="flex-1 px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-600"
              />
              <button
                type="button"
                onClick={() => {
                  if (newPlacementInput.trim()) {
                    addPlacement(newPlacementInput);
                    setNewPlacementInput('');
                  }
                }}
                className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" /> Add
              </button>
            </div>

            {/* List */}
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {placements.map((item) => (
                <div
                  key={item}
                  className="flex items-center justify-between p-2.5 bg-slate-50 hover:bg-slate-100/80 border border-slate-200/70 rounded-xl text-xs sm:text-sm"
                >
                  {editingPlacement?.original === item ? (
                    <div className="flex items-center gap-2 flex-1 mr-2">
                      <input
                        type="text"
                        value={editingPlacement.current}
                        onChange={(e) => setEditingPlacement({ ...editingPlacement, current: e.target.value })}
                        className="flex-1 px-2.5 py-1 bg-white border border-blue-500 rounded-lg text-xs"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          updatePlacement(editingPlacement.original, editingPlacement.current);
                          setEditingPlacement(null);
                        }}
                        className="p-1 bg-emerald-600 text-white rounded-md cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingPlacement(null)}
                        className="p-1 bg-slate-200 text-slate-600 rounded-md cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <span className="font-semibold text-slate-800 truncate pr-2">{item}</span>
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => setEditingPlacement({ original: item, current: item })}
                          className="p-1 text-slate-400 hover:text-blue-600 rounded cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => removePlacement(item)}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* OPTION 2: QUALIFICATIONS */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="font-bold text-slate-900 flex items-center gap-2">
                  <GraduationCap className="w-4 h-4 text-blue-600" />
                  2. Qualifications
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Available in the "Qualification" dropdown (BTech, Diploma, ITI, etc.).
                </p>
              </div>
              <span className="px-2.5 py-0.5 bg-blue-100 text-blue-800 text-xs font-bold rounded-full">
                {qualifications.length}
              </span>
            </div>

            {/* Add New Qualification Input */}
            <div className="flex gap-2">
              <input
                type="text"
                value={newQualInput}
                onChange={(e) => setNewQualInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && newQualInput.trim()) {
                    addQualification(newQualInput);
                    setNewQualInput('');
                  }
                }}
                placeholder="Add new qualification (e.g. B.Arch, ITI)..."
                className="flex-1 px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-600"
              />
              <button
                type="button"
                onClick={() => {
                  if (newQualInput.trim()) {
                    addQualification(newQualInput);
                    setNewQualInput('');
                  }
                }}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" /> Add
              </button>
            </div>

            {/* List */}
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {qualifications.map((item) => (
                <div
                  key={item}
                  className="flex items-center justify-between p-2.5 bg-slate-50 hover:bg-slate-100/80 border border-slate-200/70 rounded-xl text-xs sm:text-sm"
                >
                  {editingQual?.original === item ? (
                    <div className="flex items-center gap-2 flex-1 mr-2">
                      <input
                        type="text"
                        value={editingQual.current}
                        onChange={(e) => setEditingQual({ ...editingQual, current: e.target.value })}
                        className="flex-1 px-2.5 py-1 bg-white border border-blue-500 rounded-lg text-xs"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          updateQualification(editingQual.original, editingQual.current);
                          setEditingQual(null);
                        }}
                        className="p-1 bg-emerald-600 text-white rounded-md cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingQual(null)}
                        className="p-1 bg-slate-200 text-slate-600 rounded-md cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <span className="font-semibold text-slate-800">{item}</span>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => setEditingQual({ original: item, current: item })}
                          className="p-1 text-slate-400 hover:text-blue-600 rounded cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => removeQualification(item)}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* OPTION 3: BRANCHES / SPECIALIZATIONS */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="font-bold text-slate-900 flex items-center gap-2">
                  <Layers className="w-4 h-4 text-emerald-600" />
                  3. Academic Branches & Streams
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Available in the "Branch" dropdown on the registration form.
                </p>
              </div>
              <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-full">
                {branchesList.length}
              </span>
            </div>

            {/* Add New Branch Input */}
            <div className="flex gap-2">
              <input
                type="text"
                value={newBranchInput}
                onChange={(e) => setNewBranchInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && newBranchInput.trim()) {
                    addBranchOption(newBranchInput);
                    setNewBranchInput('');
                  }
                }}
                placeholder="Add academic branch (e.g. Mechatronics)..."
                className="flex-1 px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-600"
              />
              <button
                type="button"
                onClick={() => {
                  if (newBranchInput.trim()) {
                    addBranchOption(newBranchInput);
                    setNewBranchInput('');
                  }
                }}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" /> Add
              </button>
            </div>

            {/* List */}
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {branchesList.map((item) => (
                <div
                  key={item}
                  className="flex items-center justify-between p-2.5 bg-slate-50 hover:bg-slate-100/80 border border-slate-200/70 rounded-xl text-xs sm:text-sm"
                >
                  {editingBranch?.original === item ? (
                    <div className="flex items-center gap-2 flex-1 mr-2">
                      <input
                        type="text"
                        value={editingBranch.current}
                        onChange={(e) => setEditingBranch({ ...editingBranch, current: e.target.value })}
                        className="flex-1 px-2.5 py-1 bg-white border border-blue-500 rounded-lg text-xs"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          updateBranchOption(editingBranch.original, editingBranch.current);
                          setEditingBranch(null);
                        }}
                        className="p-1 bg-emerald-600 text-white rounded-md cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingBranch(null)}
                        className="p-1 bg-slate-200 text-slate-600 rounded-md cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <span className="font-semibold text-slate-800 truncate pr-2">{item}</span>
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => setEditingBranch({ original: item, current: item })}
                          className="p-1 text-slate-400 hover:text-blue-600 rounded cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => removeBranchOption(item)}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* OPTION 4: COLLEGES & INSTITUTES */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4 sm:col-span-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-2">
              <div>
                <h3 className="font-bold text-slate-900 flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-cyan-600" />
                  4. Colleges & Institutes Dropdown List
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Available in the "College / Institute" dropdown on the student registration form.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 bg-cyan-100 text-cyan-800 text-xs font-bold rounded-full">
                  {colleges.length} Colleges
                </span>
              </div>
            </div>

            {/* Add New College Input Form + Search */}
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={newCollegeInput}
                onChange={(e) => setNewCollegeInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && newCollegeInput.trim()) {
                    addCollege(newCollegeInput);
                    setNewCollegeInput('');
                  }
                }}
                placeholder="Enter college name (e.g. Indian Institute of Technology, Delhi)..."
                className="flex-1 px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-600"
              />
              <button
                type="button"
                onClick={() => {
                  if (newCollegeInput.trim()) {
                    addCollege(newCollegeInput);
                    setNewCollegeInput('');
                  }
                }}
                className="px-4 py-2 bg-cyan-600 hover:bg-cyan-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-colors cursor-pointer shrink-0"
              >
                <Plus className="w-4 h-4" /> Add College
              </button>
            </div>

            {/* College Search/Filter if more than 6 */}
            {colleges.length > 6 && (
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Quick search college list..."
                  value={collegeSearchFilter}
                  onChange={(e) => setCollegeSearchFilter(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 focus:outline-none focus:bg-white"
                />
              </div>
            )}

            {/* List */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-80 overflow-y-auto pr-1">
              {colleges
                .filter((col) => col.toLowerCase().includes(collegeSearchFilter.toLowerCase()))
                .map((college) => (
                  <div
                    key={college}
                    className="flex items-center justify-between p-2.5 bg-slate-50 hover:bg-slate-100/80 border border-slate-200/70 rounded-xl text-xs sm:text-sm"
                  >
                    {editingCollege?.original === college ? (
                      <div className="flex items-center gap-2 flex-1 mr-2">
                        <input
                          type="text"
                          value={editingCollege.current}
                          onChange={(e) => setEditingCollege({ ...editingCollege, current: e.target.value })}
                          className="flex-1 px-2.5 py-1 bg-white border border-blue-500 rounded-lg text-xs"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            updateCollege(editingCollege.original, editingCollege.current);
                            setEditingCollege(null);
                          }}
                          className="p-1 bg-emerald-600 text-white rounded-md cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingCollege(null)}
                          className="p-1 bg-slate-200 text-slate-600 rounded-md cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <>
                        <div className="flex items-center gap-2 min-w-0 pr-2">
                          <Building2 className="w-3.5 h-3.5 text-cyan-600 shrink-0" />
                          <span className="font-semibold text-slate-800 truncate">{college}</span>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => setEditingCollege({ original: college, current: college })}
                            className="p-1 text-slate-400 hover:text-blue-600 rounded cursor-pointer"
                            title="Edit College Name"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => removeCollege(college)}
                            className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                            title="Remove College"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                ))}
            </div>
          </div>

        </div>
      )}

      {/* =======================================================================
          MODAL: VIEW FULL REGISTRATION & DOCUMENTS
          ======================================================================= */}
      {selectedRegistration && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white w-full max-w-2xl rounded-3xl border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 max-h-[90vh] flex flex-col">
            
            {/* Modal Header */}
            <div className="p-6 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div>
                <span className="text-xs font-mono font-bold text-orange-400 uppercase tracking-wider block">
                  {selectedRegistration.registrationNumber}
                </span>
                <h2 className="text-xl font-extrabold">{selectedRegistration.name}</h2>
              </div>
              <button
                onClick={() => setSelectedRegistration(null)}
                className="p-2 hover:bg-white/10 rounded-xl text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-6">
              
              {/* Status Banner */}
              <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-xs font-bold text-slate-600">Application Status</span>
                {getStatusBadge(selectedRegistration.status)}
              </div>

              {/* Data Grid */}
              <div className="grid grid-cols-2 gap-3 text-xs sm:text-sm">
                <div className="p-3 bg-slate-50 rounded-xl">
                  <span className="text-slate-400 font-semibold block text-[11px]">Placement Track</span>
                  <span className="font-bold text-slate-800">{selectedRegistration.placement}</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl">
                  <span className="text-slate-400 font-semibold block text-[11px]">Qualification & Passing Year</span>
                  <span className="font-bold text-slate-800">
                    {selectedRegistration.qualification} ({selectedRegistration.passingYear})
                  </span>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl">
                  <span className="text-slate-400 font-semibold block text-[11px]">Branch / Specialization</span>
                  <span className="font-bold text-slate-800">{selectedRegistration.branch}</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl">
                  <span className="text-slate-400 font-semibold block text-[11px]">College / Institute</span>
                  <span className="font-bold text-slate-800">{selectedRegistration.college}</span>
                </div>
                {selectedRegistration.email && (
                  <div className="p-3 bg-slate-50 rounded-xl">
                    <span className="text-slate-400 font-semibold block text-[11px]">Email</span>
                    <a href={getEmailUrl(selectedRegistration.email, selectedRegistration.name, selectedRegistration.placement)} className="font-bold text-slate-800 hover:text-blue-600 break-all">
                      {selectedRegistration.email}
                    </a>
                  </div>
                )}
                {selectedRegistration.phone && (
                  <div className="p-3 bg-slate-50 rounded-xl">
                    <span className="text-slate-400 font-semibold block text-[11px]">Phone</span>
                    <a href={`tel:${selectedRegistration.phone}`} className="font-bold text-slate-800 hover:text-blue-600">
                      {selectedRegistration.phone}
                    </a>
                  </div>
                )}
              </div>

              {/* Direct Communication Bar in Registration Modal */}
              {(selectedRegistration.phone || selectedRegistration.email) && (
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                    Direct Student Contact
                  </span>
                  <div className="flex flex-wrap items-center gap-2">
                    {selectedRegistration.phone && (
                      <a
                        href={`tel:${selectedRegistration.phone}`}
                        className="inline-flex items-center gap-1.5 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
                      >
                        <Phone className="w-3.5 h-3.5" />
                        <span>Direct Call</span>
                      </a>
                    )}
                    {selectedRegistration.phone && (
                      <a
                        href={getWhatsAppUrl(selectedRegistration.phone, selectedRegistration.name, selectedRegistration.placement)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>WhatsApp Message</span>
                      </a>
                    )}
                    {selectedRegistration.email && (
                      <a
                        href={getEmailUrl(selectedRegistration.email, selectedRegistration.name, selectedRegistration.placement)}
                        className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
                      >
                        <Mail className="w-3.5 h-3.5" />
                        <span>Send Email</span>
                      </a>
                    )}
                  </div>
                </div>
              )}

              {/* Uploaded Documents */}
              <div>
                <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 mb-3">
                  Attached Verification Documents
                </h4>
                <div className="space-y-2.5">
                  
                  {/* Resume */}
                  <div className="flex items-center justify-between p-3 bg-blue-50/70 border border-blue-100 rounded-xl">
                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-blue-600" />
                      <div>
                        <span className="text-xs font-bold text-slate-800 block">Resume / CV</span>
                        <span className="text-[11px] text-slate-500">{selectedRegistration.resume.name}</span>
                      </div>
                    </div>
                    {selectedRegistration.resume.dataUrl && (
                      <a
                        href={selectedRegistration.resume.dataUrl}
                        download={selectedRegistration.resume.name}
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-xs"
                      >
                        <Download className="w-3.5 h-3.5" /> Download
                      </a>
                    )}
                  </div>

                  {/* Aadhaar Card */}
                  <div className="flex items-center justify-between p-3 bg-emerald-50/70 border border-emerald-100 rounded-xl">
                    <div className="flex items-center gap-3">
                      <ShieldCheck className="w-5 h-5 text-emerald-600" />
                      <div>
                        <span className="text-xs font-bold text-slate-800 block">Aadhaar Card (Identity)</span>
                        <span className="text-[11px] text-slate-500">{selectedRegistration.aadhaarCard.name}</span>
                      </div>
                    </div>
                    {selectedRegistration.aadhaarCard.dataUrl && (
                      <a
                        href={selectedRegistration.aadhaarCard.dataUrl}
                        download={selectedRegistration.aadhaarCard.name}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-xs"
                      >
                        <Download className="w-3.5 h-3.5" /> Download
                      </a>
                    )}
                  </div>

                  {/* Certificate 1 */}
                  {selectedRegistration.certificateSummer1 && (
                    <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-xl">
                      <div className="flex items-center gap-3">
                        <FileCheck className="w-5 h-5 text-slate-600" />
                        <div>
                          <span className="text-xs font-bold text-slate-800 block">Summer Internship 1 Certificate</span>
                          <span className="text-[11px] text-slate-500">{selectedRegistration.certificateSummer1.name}</span>
                        </div>
                      </div>
                      {selectedRegistration.certificateSummer1.dataUrl && (
                        <a
                          href={selectedRegistration.certificateSummer1.dataUrl}
                          download={selectedRegistration.certificateSummer1.name}
                          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-xs"
                        >
                          <Download className="w-3.5 h-3.5" /> Download
                        </a>
                      )}
                    </div>
                  )}

                  {/* Certificate 2 */}
                  {selectedRegistration.certificateSummer2 && (
                    <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-xl">
                      <div className="flex items-center gap-3">
                        <FileCheck className="w-5 h-5 text-slate-600" />
                        <div>
                          <span className="text-xs font-bold text-slate-800 block">Summer Internship 2 Certificate</span>
                          <span className="text-[11px] text-slate-500">{selectedRegistration.certificateSummer2.name}</span>
                        </div>
                      </div>
                      {selectedRegistration.certificateSummer2.dataUrl && (
                        <a
                          href={selectedRegistration.certificateSummer2.dataUrl}
                          download={selectedRegistration.certificateSummer2.name}
                          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-xs"
                        >
                          <Download className="w-3.5 h-3.5" /> Download
                        </a>
                      )}
                    </div>
                  )}

                </div>
              </div>

              {/* Admin Remarks if any */}
              {selectedRegistration.adminRemarks && (
                <div className="p-3.5 bg-amber-50/70 border border-amber-200/80 rounded-xl text-xs">
                  <span className="font-bold text-amber-900 block mb-1">Admin Verification Remarks:</span>
                  <p className="text-amber-800">{selectedRegistration.adminRemarks}</p>
                </div>
              )}

            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
              <button
                type="button"
                onClick={() => {
                  setSelectedRegistration(null);
                  handleOpenStatusModal(selectedRegistration);
                }}
                className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Edit2 className="w-3.5 h-3.5" /> Update Status & Remarks
              </button>

              <button
                type="button"
                onClick={() => setSelectedRegistration(null)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}

      {/* =======================================================================
          MODAL: UPDATE REGISTRATION STATUS & REMARKS
          ======================================================================= */}
      {statusModalOpen && editingRegistration && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white w-full max-w-md rounded-3xl border border-slate-200 shadow-2xl p-6 space-y-4 animate-in fade-in zoom-in-95">
            <h3 className="font-extrabold text-slate-900 text-lg">
              Update Registration Status
            </h3>
            <p className="text-xs text-slate-500">
              For student: <span className="font-bold text-slate-800">{editingRegistration.name}</span> ({editingRegistration.registrationNumber})
            </p>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                  Select Status
                </label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value as StudentRegistrationStatus)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-800"
                >
                  <option value="Pending">Pending</option>
                  <option value="Under Review">Under Review</option>
                  <option value="Shortlisted">Shortlisted</option>
                  <option value="Approved">Approved</option>
                  <option value="Rejected">Rejected</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
                  Admin Verification Remarks
                </label>
                <textarea
                  rows={3}
                  value={adminRemarks}
                  onChange={(e) => setAdminRemarks(e.target.value)}
                  placeholder="e.g. Verified Aadhaar & BTech credentials. Qualified for Round 1 interview."
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-100 focus:border-blue-600"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setStatusModalOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveStatus}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
