import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Bell,
  MessageSquare,
  GraduationCap,
  ChevronDown,
  User,
  LayoutDashboard,
  Settings,
  LogOut,
  Menu,
  X,
  Briefcase,
  Layers,
  Sparkles,
  Award
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    currentRole,
    setRole,
    currentUser,
    currentView,
    navigateTo,
    setIsLoginOpen,
    notifications,
    conversations,
  } = useApp();

  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);

  const unreadNotifs = notifications.filter((n) => !n.isRead).length;
  const unreadMessages = conversations.reduce((acc, c) => acc + c.unreadCount, 0);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setIsProfileOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navLinks = [
    { label: 'Home', view: 'home' },
    { label: 'Apply / Contact', view: 'application' },
    { label: 'Student Registration', view: 'student-registration' },
    { label: 'Programs', view: 'all-programs' },
    { label: 'Certificates', view: 'student-certificates' },
    { label: 'Admin Dashboard', view: 'admin-management' },
  ];

  const getDashboardView = () => {
    switch (currentRole) {
      case 'student':
        return 'student-certificates';
      case 'mentor':
      case 'employer':
        return 'all-programs';
      case 'admin':
      case 'super_admin':
        return 'admin-management';
      default:
        return 'home';
    }
  };

  return (
    <header className="no-print sticky top-[33px] z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Left: Brand Logo */}
          <div className="flex items-center gap-8">
            <button
              id="header-logo-btn"
              onClick={() => navigateTo('home')}
              className="flex items-center gap-2 text-left group cursor-pointer focus:outline-none"
            >
              <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:bg-blue-700 transition-colors">
                <GraduationCap className="w-6 h-6 stroke-[2.2]" />
              </div>
              <div>
                <span className="text-xl font-extrabold tracking-tight text-slate-900 flex items-center gap-1">
                  Skill<span className="text-blue-600">Nest</span>
                </span>
                <span className="text-[10px] block font-medium text-slate-400 tracking-wider uppercase -mt-1">
                  Careers & Training
                </span>
              </div>
            </button>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2">
              {navLinks.map((link) => {
                const isActive = currentView === link.view;
                return (
                  <button
                    key={link.label}
                    id={`nav-${link.label.toLowerCase()}`}
                    onClick={() => navigateTo(link.view)}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                      isActive
                        ? 'text-blue-600 bg-blue-50/70 font-semibold'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    {link.label}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            {currentRole === 'guest' ? (
              // Guest Action: Single Sign Up Button
              <div className="flex items-center">
                <button
                  id="btn-header-signup"
                  onClick={() => setIsLoginOpen(true)}
                  className="px-4 sm:px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm hover:shadow transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <span>Sign Up</span>
                </button>
              </div>
            ) : (
              // Authenticated Actions
              <div className="flex items-center gap-2 sm:gap-3">
                {/* Notifications Bell */}
                <button
                  id="btn-header-notifs"
                  onClick={() => navigateTo('notifications')}
                  className="relative p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                  title="Notifications"
                >
                  <Bell className="w-5 h-5" />
                  {unreadNotifs > 0 && (
                    <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                      {unreadNotifs}
                    </span>
                  )}
                </button>

                {/* Messages Chat Icon */}
                <button
                  id="btn-header-messages"
                  onClick={() => navigateTo('messages')}
                  className="relative p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                  title="Messages"
                >
                  <MessageSquare className="w-5 h-5" />
                  {unreadMessages > 0 && (
                    <span className="absolute top-1 right-1 w-4 h-4 bg-blue-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                      {unreadMessages}
                    </span>
                  )}
                </button>

                {/* Profile Dropdown */}
                <div className="relative" ref={profileRef}>
                  <button
                    id="btn-user-profile-menu"
                    onClick={() => setIsProfileOpen(!isProfileOpen)}
                    className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer focus:outline-none"
                  >
                    <img
                      src={currentUser.avatar}
                      alt={currentUser.name}
                      className="w-8 h-8 rounded-lg object-cover ring-1 ring-slate-200"
                    />
                    <div className="hidden md:block text-left">
                      <p className="text-xs font-bold text-slate-900 leading-tight">{currentUser.name}</p>
                      <span className="text-[10px] font-medium text-blue-600 capitalize bg-blue-50 px-1.5 py-0.5 rounded">
                        {currentRole.replace('_', ' ')}
                      </span>
                    </div>
                    <ChevronDown className="w-4 h-4 text-slate-400" />
                  </button>

                  {isProfileOpen && (
                    <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100">
                      <div className="px-3 py-2 border-b border-slate-100">
                        <p className="text-sm font-semibold text-slate-900">{currentUser.name}</p>
                        <p className="text-xs text-slate-500 truncate">{currentUser.email}</p>
                      </div>

                      <button
                        id="menu-my-dashboard"
                        onClick={() => {
                          setIsProfileOpen(false);
                          navigateTo(getDashboardView());
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 hover:text-blue-600 transition-colors cursor-pointer"
                      >
                        <LayoutDashboard className="w-4 h-4" />
                        <span>My Dashboard</span>
                      </button>

                      <button
                        id="menu-my-certificates"
                        onClick={() => {
                          setIsProfileOpen(false);
                          navigateTo('student-certificates');
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 hover:text-blue-600 transition-colors cursor-pointer"
                      >
                        <Award className="w-4 h-4" />
                        <span>My Certificates</span>
                      </button>

                      {currentRole === 'student' && (
                        <>
                          <button
                            id="menu-my-certificates"
                            onClick={() => {
                              setIsProfileOpen(false);
                              navigateTo('student-certificates');
                            }}
                            className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 hover:text-blue-600 transition-colors cursor-pointer"
                          >
                            <GraduationCap className="w-4 h-4" />
                            <span>My Certificates</span>
                          </button>
                        </>
                      )}

                      {(currentRole === 'admin' || currentRole === 'super_admin') && (
                        <button
                          id="menu-admin-management"
                          onClick={() => {
                            setIsProfileOpen(false);
                            navigateTo('admin-management');
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 hover:text-blue-600 transition-colors cursor-pointer"
                        >
                          <Settings className="w-4 h-4" />
                          <span>Admin Control Panel</span>
                        </button>
                      )}

                      <div className="border-t border-slate-100 my-1"></div>

                      <button
                        id="menu-logout"
                        onClick={() => {
                          setIsProfileOpen(false);
                          setRole('guest');
                          navigateTo('home');
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>Sign Out (Guest Mode)</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Mobile menu toggle button */}
            <button
              id="btn-mobile-menu-toggle"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 text-slate-500 hover:text-slate-700 lg:hidden rounded-lg cursor-pointer"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile navigation drawer */}
      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-2 pb-4 space-y-1">
          {navLinks.map((link) => (
            <button
              key={link.label}
              onClick={() => {
                navigateTo(link.view);
                setIsMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2 rounded-lg text-base font-medium text-slate-700 hover:bg-slate-50 hover:text-blue-600 cursor-pointer"
            >
              {link.label}
            </button>
          ))}
          {currentRole !== 'guest' ? (
            <button
              onClick={() => {
                navigateTo(getDashboardView());
                setIsMobileMenuOpen(false);
              }}
              className="w-full text-left px-3 py-2 rounded-lg text-base font-medium text-blue-600 bg-blue-50 cursor-pointer"
            >
              Go to Dashboard
            </button>
          ) : (
            <div className="pt-2 border-t border-slate-100">
              <button
                id="btn-mobile-signup"
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  setIsLoginOpen(true);
                }}
                className="w-full py-2.5 px-3 rounded-lg text-base font-semibold text-white bg-blue-600 hover:bg-blue-700 text-center cursor-pointer shadow-sm"
              >
                Sign Up
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};
