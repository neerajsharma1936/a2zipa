import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { GraduationCap, Mail, ArrowRight, CheckCircle, ShieldCheck, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  const { navigateTo, setRole, showToast, contactDetails } = useApp();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubscribed(true);
    showToast('Subscribed to SkillNest Career Digest!', 'success');
  };

  return (
    <footer className="no-print bg-slate-900 text-slate-400 pt-16 pb-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-slate-800">
          
          {/* Col 1: Brand */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
                <GraduationCap className="w-6 h-6 stroke-[2.2]" />
              </div>
              <span className="text-2xl font-extrabold tracking-tight text-white">
                Skill<span className="text-blue-500">Nest</span>
              </span>
            </div>
            <p className="text-sm text-slate-400 max-w-sm leading-relaxed">
              Build Skills. Gain Experience. Launch Your Career. SkillNest unites forward-thinking students, industry mentors, and hiring companies in one integrated ecosystem.
            </p>
            
            {/* Newsletter */}
            <div className="pt-2">
              <p className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Join our weekly career newsletter
              </p>
              {subscribed ? (
                <div className="flex items-center gap-2 text-emerald-400 text-sm bg-emerald-950/40 p-2.5 rounded-lg border border-emerald-800">
                  <CheckCircle className="w-4 h-4" />
                  <span>You're subscribed to weekly internship alerts!</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex max-w-md gap-2">
                  <input
                    type="email"
                    required
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="flex-1 bg-slate-800 text-white text-sm px-3.5 py-2.5 rounded-lg border border-slate-700 focus:outline-none focus:border-blue-500"
                  />
                  <button
                    type="submit"
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg font-medium text-sm transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>Join</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Col 2: For Candidates */}
          <div>
            <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">
              For Students
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button onClick={() => navigateTo('application')} className="hover:text-blue-400 transition-colors cursor-pointer text-blue-400 font-medium">
                  Apply / Contact Us
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('all-programs')} className="hover:text-blue-400 transition-colors cursor-pointer">
                  Featured Programs
                </button>
              </li>
              <li>
                <button onClick={() => { setRole('student'); navigateTo('student-certificates'); }} className="hover:text-blue-400 transition-colors cursor-pointer">
                  Certificates Verification
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('notifications')} className="hover:text-blue-400 transition-colors cursor-pointer">
                  Campus Notifications
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('messages')} className="hover:text-blue-400 transition-colors cursor-pointer">
                  Direct Messages
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Role Portals */}
          <div>
            <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">
              Role Portals
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button onClick={() => { setRole('student'); navigateTo('student-certificates'); }} className="hover:text-blue-400 transition-colors cursor-pointer flex items-center gap-1">
                  <span>Student Portal</span>
                </button>
              </li>
              <li>
                <button onClick={() => { setRole('mentor'); navigateTo('all-programs'); }} className="hover:text-blue-400 transition-colors cursor-pointer flex items-center gap-1">
                  <span>Academic Programs</span>
                </button>
              </li>
              <li>
                <button onClick={() => { setRole('admin'); navigateTo('admin-management'); }} className="hover:text-blue-400 transition-colors cursor-pointer flex items-center gap-1">
                  <span>Admin Management</span>
                </button>
              </li>
              <li>
                <button onClick={() => { setRole('super_admin'); navigateTo('admin-management'); }} className="hover:text-blue-400 transition-colors cursor-pointer flex items-center gap-1">
                  <span>Super Admin Console</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Verification & Trust */}
          <div>
            <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">
              Trust & Support
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button onClick={() => navigateTo('verify-certificate')} className="hover:text-blue-400 transition-colors cursor-pointer flex items-center gap-1 text-emerald-400">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Verify Certificate</span>
                </button>
              </li>
              {contactDetails?.phone && (
                <li className="text-xs text-slate-300">
                  <span className="text-slate-500 block">Helpline:</span>
                  <a href={`tel:${contactDetails.phone}`} className="hover:text-blue-400 font-medium">
                    {contactDetails.phone}
                  </a>
                </li>
              )}
              {contactDetails?.email && (
                <li className="text-xs text-slate-300">
                  <span className="text-slate-500 block">Admissions:</span>
                  <a href={`mailto:${contactDetails.email}`} className="hover:text-blue-400 font-medium">
                    {contactDetails.email}
                  </a>
                </li>
              )}
              <li>
                <button onClick={() => navigateTo('home')} className="hover:text-blue-400 transition-colors cursor-pointer">
                  Hiring Partner Terms
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('home')} className="hover:text-blue-400 transition-colors cursor-pointer">
                  Privacy Policy
                </button>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© {new Date().getFullYear()} SkillNest Technologies Inc. All rights reserved.</p>
          <div className="flex items-center gap-1 text-slate-400">
            <span>Crafted for modern student careers with excellence</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
