import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  LayoutDashboard,
  User,
  Search,
  Bookmark,
  Briefcase,
  BookOpen,
  FolderGit2,
  FileCheck2,
  Calendar,
  Award,
  MessageSquare,
  Bell,
  Settings,
  PlusCircle,
  Users,
  CheckCircle2,
  BarChart3,
  LogOut,
  Building2,
  ShieldCheck,
  GraduationCap,
  Sparkles
} from 'lucide-react';

interface DashboardSidebarProps {
  activeTab?: string;
  onTabChange?: (tab: string) => void;
}

export const DashboardSidebar: React.FC<DashboardSidebarProps> = ({ activeTab, onTabChange }) => {
  const { currentRole, currentView, navigateTo, setRole } = useApp();

  // Define sidebar menu items based on role
  let menuItems: { id: string; label: string; icon: React.ReactNode; viewTarget?: string }[] = [];

  if (currentRole === 'student') {
    menuItems = [
      { id: 'programs', label: 'All Programs', icon: <BookOpen className="w-4 h-4" />, viewTarget: 'all-programs' },
      { id: 'registration', label: 'Student Registration', icon: <Users className="w-4 h-4" />, viewTarget: 'student-registration' },
      { id: 'certificates', label: 'Certificates', icon: <Award className="w-4 h-4" />, viewTarget: 'student-certificates' },
      { id: 'messages', label: 'Messages', icon: <MessageSquare className="w-4 h-4" />, viewTarget: 'messages' },
      { id: 'notifications', label: 'Notifications', icon: <Bell className="w-4 h-4" />, viewTarget: 'notifications' },
    ];
  } else if (currentRole === 'mentor') {
    menuItems = [
      { id: 'programs', label: 'All Programs', icon: <BookOpen className="w-4 h-4" />, viewTarget: 'all-programs' },
      { id: 'messages', label: 'Messages', icon: <MessageSquare className="w-4 h-4" />, viewTarget: 'messages' },
      { id: 'notifications', label: 'Notifications', icon: <Bell className="w-4 h-4" />, viewTarget: 'notifications' },
      { id: 'certificates', label: 'Certificates', icon: <Award className="w-4 h-4" />, viewTarget: 'student-certificates' },
    ];
  } else if (currentRole === 'employer') {
    menuItems = [
      { id: 'programs', label: 'All Programs', icon: <BookOpen className="w-4 h-4" />, viewTarget: 'all-programs' },
      { id: 'messages', label: 'Messages', icon: <MessageSquare className="w-4 h-4" />, viewTarget: 'messages' },
      { id: 'notifications', label: 'Notifications', icon: <Bell className="w-4 h-4" />, viewTarget: 'notifications' },
    ];
  } else {
    // Admin / Super Admin
    menuItems = [
      { id: 'programs', label: 'All Programs', icon: <BookOpen className="w-4 h-4" />, viewTarget: 'admin-management' },
      { id: 'registrations-mgmt', label: 'Student Registrations', icon: <Users className="w-4 h-4" />, viewTarget: 'admin-management' },
      { id: 'banners-mgmt', label: 'Hero Banners', icon: <Sparkles className="w-4 h-4" />, viewTarget: 'admin-management' },
      { id: 'dropdowns-mgmt', label: 'Form Options', icon: <ShieldCheck className="w-4 h-4" />, viewTarget: 'admin-management' },
      { id: 'certificates', label: 'Certificates Verification', icon: <Award className="w-4 h-4" />, viewTarget: 'student-certificates' },
      { id: 'messages', label: 'Communications', icon: <MessageSquare className="w-4 h-4" />, viewTarget: 'messages' },
      { id: 'notifications', label: 'System Alerts', icon: <Bell className="w-4 h-4" />, viewTarget: 'notifications' },
    ];
  }

  return (
    <aside className="w-64 shrink-0 bg-[#071B49] text-white border-r border-[#0E2864] sticky top-[97px] h-[calc(100vh-97px)] py-5 px-3 hidden md:flex flex-col justify-between overflow-y-auto select-none z-30 shadow-md">
      <div className="space-y-1">
        {menuItems.map((item) => {
          // Strictly highlight only the active item: if activeTab is passed, check item.id; otherwise match viewTarget
          const isSelected = activeTab
            ? activeTab === item.id
            : currentView === item.viewTarget;

          return (
            <button
              key={item.id}
              id={`sidebar-item-${item.id}`}
              onClick={() => {
                if (onTabChange) onTabChange(item.id);
                if (item.viewTarget && currentView !== item.viewTarget) navigateTo(item.viewTarget);
              }}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs transition-all cursor-pointer ${
                isSelected
                  ? 'bg-[#146EF5] text-white font-bold shadow-md shadow-blue-600/30 border border-blue-400/40'
                  : 'text-slate-300 hover:text-white hover:bg-white/10 font-medium bg-transparent border border-transparent'
              }`}
            >
              <div className={isSelected ? 'text-white' : 'text-slate-400'}>
                {item.icon}
              </div>
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Bottom info card */}
      <div className="pt-4 border-t border-white/10 px-2 space-y-2">
        <button
          onClick={() => {
            setRole('guest');
            navigateTo('home');
          }}
          className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-rose-300 hover:text-white hover:bg-rose-500/20 rounded-xl transition-colors cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>Exit to Guest Home</span>
        </button>
      </div>
    </aside>
  );
};
