import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';
import {
  X,
  GraduationCap,
  Briefcase,
  UserCheck,
  Shield,
  Sparkles,
  ArrowRight,
  UserPlus,
  Lock,
  Mail,
  User as UserIcon,
} from 'lucide-react';

export const LoginModal: React.FC = () => {
  const { isLoginOpen, setIsLoginOpen, setRole, navigateTo, showToast } = useApp();
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [selectedRole, setSelectedRole] = useState<UserRole>('student');

  if (!isLoginOpen) return null;

  const handleCustomLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    // Detect role or default to student
    let role: UserRole = 'student';
    if (email.includes('mentor')) role = 'mentor';
    else if (email.includes('employer') || email.includes('techcorp')) role = 'employer';
    else if (email.includes('admin') || email.includes('anil')) role = 'super_admin';

    setRole(role);
    setIsLoginOpen(false);
    showToast(`Logged in successfully as ${email}`, 'success');
  };

  const handleCreateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setRole(selectedRole);
    setIsLoginOpen(false);
    showToast(`Account created for ${fullName || email}! Welcome to SkillNest.`, 'success');
    if (selectedRole === 'student') {
      navigateTo('student-certificates');
    } else if (selectedRole === 'employer' || selectedRole === 'mentor') {
      navigateTo('all-programs');
    } else {
      navigateTo('admin-management');
    }
  };

  const handleRoleQuickLogin = (role: UserRole) => {
    setRole(role);
    setIsLoginOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-150">
        
        {/* Modal Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-xl font-bold text-slate-900">
              {authMode === 'signin' ? 'Sign In to SkillNest' : 'Create New Account'}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {authMode === 'signin'
                ? 'Access internships, courses & career dashboards'
                : 'Join SkillNest to launch your career journey'}
            </p>
          </div>
          <button
            onClick={() => setIsLoginOpen(false)}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* Quick Demo One-Click Role Logins */}
          <div>
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2.5 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>Quick Demo 1-Click Access</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                id="login-quick-student"
                onClick={() => handleRoleQuickLogin('student')}
                className="flex items-center gap-2 p-2.5 rounded-xl border border-blue-200 bg-blue-50/50 hover:bg-blue-100/70 text-left transition-colors cursor-pointer group"
              >
                <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0">
                  <GraduationCap className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">Student</p>
                  <p className="text-[10px] text-slate-500">Rahul Sharma</p>
                </div>
              </button>

              <button
                id="login-quick-employer"
                onClick={() => handleRoleQuickLogin('employer')}
                className="flex items-center gap-2 p-2.5 rounded-xl border border-indigo-200 bg-indigo-50/50 hover:bg-indigo-100/70 text-left transition-colors cursor-pointer group"
              >
                <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0">
                  <Briefcase className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">Employer</p>
                  <p className="text-[10px] text-slate-500">TechCorp Recruiter</p>
                </div>
              </button>

              <button
                id="login-quick-mentor"
                onClick={() => handleRoleQuickLogin('mentor')}
                className="flex items-center gap-2 p-2.5 rounded-xl border border-emerald-200 bg-emerald-50/50 hover:bg-emerald-100/70 text-left transition-colors cursor-pointer group"
              >
                <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
                  <UserCheck className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">Mentor</p>
                  <p className="text-[10px] text-slate-500">Dr. Priya Patel</p>
                </div>
              </button>

              <button
                id="login-quick-super-admin"
                onClick={() => handleRoleQuickLogin('super_admin')}
                className="flex items-center gap-2 p-2.5 rounded-xl border border-purple-200 bg-purple-50/50 hover:bg-purple-100/70 text-left transition-colors cursor-pointer group"
              >
                <div className="w-8 h-8 rounded-lg bg-purple-600 text-white flex items-center justify-center shrink-0">
                  <Shield className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">Super Admin</p>
                  <p className="text-[10px] text-slate-500">Platform Control</p>
                </div>
              </button>
            </div>
          </div>

          <div className="relative flex py-1 items-center">
            <div className="flex-grow border-t border-slate-200"></div>
            <span className="flex-shrink mx-3 text-[11px] font-medium text-slate-400 uppercase">
              {authMode === 'signin' ? 'Or sign in with email' : 'Or enter account details'}
            </span>
            <div className="flex-grow border-t border-slate-200"></div>
          </div>

          {authMode === 'signin' ? (
            /* Standard Login Form */
            <form onSubmit={handleCustomLogin} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Email address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="email"
                    required
                    placeholder="name@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full text-sm pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 text-slate-900"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="text-xs font-semibold text-slate-700">Password</label>
                  <button
                    type="button"
                    onClick={() => showToast('Password reset link sent to demo email', 'info')}
                    className="text-xs text-blue-600 hover:underline cursor-pointer"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full text-sm pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 text-slate-900"
                  />
                </div>
              </div>

              {/* ACTION RIGHT AFTER PASSWORD INPUT: CREATE NEW ACCOUNT */}
              <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-100 flex items-center justify-between gap-2">
                <div className="text-xs text-slate-600">
                  <span>Don't have an account?</span>
                </div>
                <button
                  type="button"
                  id="btn-create-new-account"
                  onClick={() => setAuthMode('signup')}
                  className="px-3 py-1.5 bg-white text-blue-600 font-bold text-xs rounded-lg border border-blue-200 hover:bg-blue-600 hover:text-white transition-all shadow-xs flex items-center gap-1 cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Create new account</span>
                </button>
              </div>

              <button
                type="submit"
                id="btn-submit-signin"
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm rounded-xl transition-colors shadow-sm cursor-pointer flex items-center justify-center gap-1.5"
              >
                <span>Sign In</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          ) : (
            /* Create New Account Form */
            <form onSubmit={handleCreateAccount} className="space-y-3.5">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Full Name</label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    placeholder="e.g. Rahul Sharma"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full text-sm pl-9 pr-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Email address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="email"
                    required
                    placeholder="name@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full text-sm pl-9 pr-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Password</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="password"
                    required
                    placeholder="At least 6 characters"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full text-sm pl-9 pr-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1.5">I am registering as:</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['student', 'employer', 'mentor'] as UserRole[]).map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setSelectedRole(r)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-semibold capitalize border transition-all cursor-pointer ${
                        selectedRole === r
                          ? 'border-blue-600 bg-blue-50 text-blue-700 shadow-xs'
                          : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                id="btn-submit-create-account"
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm rounded-xl transition-colors shadow-sm cursor-pointer flex items-center justify-center gap-1.5 mt-2"
              >
                <span>Create Account</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                <span>Already have an account?</span>
                <button
                  type="button"
                  onClick={() => setAuthMode('signin')}
                  className="text-blue-600 font-bold hover:underline cursor-pointer"
                >
                  Sign In instead
                </button>
              </div>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
